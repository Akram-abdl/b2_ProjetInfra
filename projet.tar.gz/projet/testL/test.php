<?php
$output = shell_exec('./oui.sh');
echo "<pre>$output</pre>";
?>