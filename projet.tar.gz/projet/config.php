<?php
$TEMPLATE_CONFIG_PATH = "../scripts/templates/config.json";
$CONFIG_FOLDER = "../scripts/config";
