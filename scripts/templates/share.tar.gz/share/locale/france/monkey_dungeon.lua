

add_goto_npc_for_monkey_dungeon(5, 145, 315, 345, 361) ;
add_goto_npc_for_monkey_dungeon(5, 80,  308, 106, 547) ;
add_goto_npc_for_monkey_dungeon(5, 206, 109, 75,  368) ;
add_goto_npc_for_monkey_dungeon(5, 320, 238, 89,  746) ;
add_goto_npc_for_monkey_dungeon(5, 421, 272, 520, 352) ;
add_goto_npc_for_monkey_dungeon(5, 487, 279, 541, 45) ;
add_goto_npc_for_monkey_dungeon(5, 70,  368, 211, 109) ;
add_goto_npc_for_monkey_dungeon(5, 65,  434, 615, 49) ;
add_goto_npc_for_monkey_dungeon(5, 67,  498, 284, 705) ;
add_goto_npc_for_monkey_dungeon(5, 350, 361, 145, 310) ;
add_goto_npc_for_monkey_dungeon(5, 210, 495, 553, 285) ;
add_goto_npc_for_monkey_dungeon(5, 526, 352, 487, 274) ;
add_goto_npc_for_monkey_dungeon(5, 528, 415, 626, 291) ;
add_goto_npc_for_monkey_dungeon(5, 523, 480, 285, 569) ;
add_goto_npc_for_monkey_dungeon(5, 101, 547, 80,  303) ;
add_goto_npc_for_monkey_dungeon(5, 82,  746, 315, 238) ;
add_goto_npc_for_monkey_dungeon(5, 541, 40,  416, 272) ;
add_goto_npc_for_monkey_dungeon(5, 615, 44,  72,  498) ;
add_goto_npc_for_monkey_dungeon(5, 553, 291, 215, 495) ;
add_goto_npc_for_monkey_dungeon(5, 626, 296, 523, 415) ;
add_goto_npc_for_monkey_dungeon(5, 278, 705, 72,  498) ;
add_goto_npc_for_monkey_dungeon(5, 280, 569, 518, 480) ;
add_goto_npc_for_monkey_dungeon(5, 470, 560, 583, 379) ;
add_goto_npc_for_monkey_dungeon(5, 579, 390, 459, 558) ;


add_goto_npc_for_monkey_dungeon(25, 145, 315, 345, 361) ;
add_goto_npc_for_monkey_dungeon(25, 80,  308, 106, 547) ;
add_goto_npc_for_monkey_dungeon(25, 206, 109, 75,  368) ;
add_goto_npc_for_monkey_dungeon(25, 320, 238, 89,  746) ;
add_goto_npc_for_monkey_dungeon(25, 421, 272, 520, 352) ;
add_goto_npc_for_monkey_dungeon(25, 487, 279, 541, 45) ;
add_goto_npc_for_monkey_dungeon(25, 70,  368, 211, 109) ;
add_goto_npc_for_monkey_dungeon(25, 65,  434, 615, 49) ;
add_goto_npc_for_monkey_dungeon(25, 67,  498, 284, 705) ;
add_goto_npc_for_monkey_dungeon(25, 350, 361, 145, 310) ;
add_goto_npc_for_monkey_dungeon(25, 210, 495, 553, 285) ;
add_goto_npc_for_monkey_dungeon(25, 526, 352, 487, 274) ;
add_goto_npc_for_monkey_dungeon(25, 528, 415, 626, 291) ;
add_goto_npc_for_monkey_dungeon(25, 523, 480, 285, 569) ;
add_goto_npc_for_monkey_dungeon(25, 101, 547, 80,  303) ;
add_goto_npc_for_monkey_dungeon(25, 82,  746, 315, 238) ;
add_goto_npc_for_monkey_dungeon(25, 541, 40,  416, 272) ;
add_goto_npc_for_monkey_dungeon(25, 615, 44,  72,  498) ;
add_goto_npc_for_monkey_dungeon(25, 553, 291, 215, 495) ;
add_goto_npc_for_monkey_dungeon(25, 626, 296, 523, 415) ;
add_goto_npc_for_monkey_dungeon(25, 278, 705, 72,  498) ;
add_goto_npc_for_monkey_dungeon(25, 280, 569, 518, 480) ;
add_goto_npc_for_monkey_dungeon(25, 470, 560, 583, 379) ;
add_goto_npc_for_monkey_dungeon(25, 579, 390, 459, 558) ;


add_goto_npc_for_monkey_dungeon(45, 145, 315, 345, 361) ;
add_goto_npc_for_monkey_dungeon(45, 80,  308, 106, 547) ;
add_goto_npc_for_monkey_dungeon(45, 206, 109, 75,  368) ;
add_goto_npc_for_monkey_dungeon(45, 320, 238, 89,  746) ;
add_goto_npc_for_monkey_dungeon(45, 421, 272, 520, 352) ;
add_goto_npc_for_monkey_dungeon(45, 487, 279, 541, 45) ;
add_goto_npc_for_monkey_dungeon(45, 70,  368, 211, 109) ;
add_goto_npc_for_monkey_dungeon(45, 65,  434, 615, 49) ;
add_goto_npc_for_monkey_dungeon(45, 67,  498, 284, 705) ;
add_goto_npc_for_monkey_dungeon(45, 350, 361, 145, 310) ;
add_goto_npc_for_monkey_dungeon(45, 210, 495, 553, 285) ;
add_goto_npc_for_monkey_dungeon(45, 526, 352, 487, 274) ;
add_goto_npc_for_monkey_dungeon(45, 528, 415, 626, 291) ;
add_goto_npc_for_monkey_dungeon(45, 523, 480, 285, 569) ;
add_goto_npc_for_monkey_dungeon(45, 101, 547, 80,  303) ;
add_goto_npc_for_monkey_dungeon(45, 82,  746, 315, 238) ;
add_goto_npc_for_monkey_dungeon(45, 541, 40,  416, 272) ;
add_goto_npc_for_monkey_dungeon(45, 615, 44,  72,  498) ;
add_goto_npc_for_monkey_dungeon(45, 553, 291, 215, 495) ;
add_goto_npc_for_monkey_dungeon(45, 626, 296, 523, 415) ;
add_goto_npc_for_monkey_dungeon(45, 278, 705, 72,  498) ;
add_goto_npc_for_monkey_dungeon(45, 280, 569, 518, 480) ;
add_goto_npc_for_monkey_dungeon(45, 470, 560, 583, 379) ;
add_goto_npc_for_monkey_dungeon(45, 579, 390, 459, 558) ;


add_goto_npc_for_monkey_dungeon(108, 145, 315, 345, 361) ;
add_goto_npc_for_monkey_dungeon(108, 80,  308, 520, 352) ;
add_goto_npc_for_monkey_dungeon(108, 206, 109, 487, 274) ;
add_goto_npc_for_monkey_dungeon(108, 320, 238, 75,  368) ;
add_goto_npc_for_monkey_dungeon(108, 421, 272, 211, 109) ;
add_goto_npc_for_monkey_dungeon(108, 487, 279, 215, 495) ;
add_goto_npc_for_monkey_dungeon(108, 70,  368, 315, 238) ;
add_goto_npc_for_monkey_dungeon(108, 65,  434, 520, 352) ;
add_goto_npc_for_monkey_dungeon(108, 67,  498, 284, 705) ;
add_goto_npc_for_monkey_dungeon(108, 350, 361, 145, 310) ;
add_goto_npc_for_monkey_dungeon(108, 210, 495, 416, 272) ;
add_goto_npc_for_monkey_dungeon(108, 526, 352, 80,  303) ;
add_goto_npc_for_monkey_dungeon(108, 528, 415, 72,  498) ;
add_goto_npc_for_monkey_dungeon(108, 523, 480, 106, 547) ;
add_goto_npc_for_monkey_dungeon(108, 101, 547, 523, 415) ;
add_goto_npc_for_monkey_dungeon(108, 82,  746, 541, 45) ;
add_goto_npc_for_monkey_dungeon(108, 541, 40,  72,  121) ;
add_goto_npc_for_monkey_dungeon(108, 615, 44,  518, 480) ;
add_goto_npc_for_monkey_dungeon(108, 553, 291, 89,  746) ;
add_goto_npc_for_monkey_dungeon(108, 626, 296, 285, 569) ;
add_goto_npc_for_monkey_dungeon(108, 278, 705, 615, 49) ;
add_goto_npc_for_monkey_dungeon(108, 280, 569, 72,  498) ;
add_goto_npc_for_monkey_dungeon(108, 470, 560, 583, 379) ;
add_goto_npc_for_monkey_dungeon(108, 579, 390, 459, 558) ;
add_goto_npc_for_monkey_dungeon(108, 597, 331, 609, 553) ;
add_goto_npc_for_monkey_dungeon(108, 607, 559, 594, 338) ;

add_goto_npc_for_monkey_dungeon(109, 145, 315, 75,  368) ;
add_goto_npc_for_monkey_dungeon(109, 80,  308, 541, 45 ) ;
add_goto_npc_for_monkey_dungeon(109, 206, 109, 615, 49 ) ;
add_goto_npc_for_monkey_dungeon(109, 320, 238, 284, 705) ;
add_goto_npc_for_monkey_dungeon(109, 421, 272, 520, 352) ;
add_goto_npc_for_monkey_dungeon(109, 487, 279, 553, 285) ;
add_goto_npc_for_monkey_dungeon(109, 70,  368, 145, 310) ;
add_goto_npc_for_monkey_dungeon(109, 65,  434, 345, 361) ;
add_goto_npc_for_monkey_dungeon(109, 67,  498, 523, 415) ;
add_goto_npc_for_monkey_dungeon(109, 350, 361, 72,  498) ;
add_goto_npc_for_monkey_dungeon(109, 210, 495, 626, 291) ;
add_goto_npc_for_monkey_dungeon(109, 526, 352, 487, 274) ;
add_goto_npc_for_monkey_dungeon(109, 528, 415, 72,  498) ;
add_goto_npc_for_monkey_dungeon(109, 523, 480, 106, 547) ;
add_goto_npc_for_monkey_dungeon(109, 101, 547, 518, 480) ;
add_goto_npc_for_monkey_dungeon(109, 82,  746, 285, 569) ;
add_goto_npc_for_monkey_dungeon(109, 541, 40,  80,  303) ;
add_goto_npc_for_monkey_dungeon(109, 615, 44,  211, 109) ;
add_goto_npc_for_monkey_dungeon(109, 553, 291, 416, 272) ;
add_goto_npc_for_monkey_dungeon(109, 626, 296, 215, 495) ;
add_goto_npc_for_monkey_dungeon(109, 278, 705, 315, 238) ;
add_goto_npc_for_monkey_dungeon(109, 280, 569, 89,  746) ;
add_goto_npc_for_monkey_dungeon(109, 470, 560, 583, 379) ;
add_goto_npc_for_monkey_dungeon(109, 579, 390, 459, 558) ;
add_goto_npc_for_monkey_dungeon(109, 597, 331, 609, 553) ;
add_goto_npc_for_monkey_dungeon(109, 607, 559, 594, 338) ;




