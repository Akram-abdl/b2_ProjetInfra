-- /goto #??
-- add_goto_info("string_type_name", 0, map_name, x, y)
add_goto_info("e1", 0, 1, 428, 350)
add_goto_info("e2", 0, 21, 639, 3200)
add_goto_info("e3", 0, 41, 384, 4736)
add_goto_info("inter_zone", 0, 61, 4174, 2140)
add_goto_info("z20", 0, 7, 2687, 512)
add_goto_info("z30", 0, 8, 3461, 143)
add_goto_info("z40", 0, 9, 4488, 142)
add_goto_info("z50", 0, 10, 4508, 1167)
add_goto_info("z60", 0, 11, 6395, 31)
add_goto_info("z70", 0, 62, 1618, 3397)
add_goto_info("z75", 0, 63, 2495, 4803)
add_goto_info("z80", 0, 64, 3648, 2962)
add_goto_info("z85", 0, 65, 5025, 3595)
add_goto_info("z90", 0, 66, 6076, 2921)
add_goto_info("z95", 0, 67, 6512, 3727)

add_goto_info("wedding", 0, 81, 8250, 25)
add_goto_info("oxevent", 0, 113, 8964, 215)

arena.add_map(112, 8534, 101, 8564, 101)
arena.add_map(112, 8584, 101, 8614, 101)
arena.add_map(112, 8534, 155, 8564, 155)
arena.add_map(112, 8584, 155, 8614, 155)

add_bgm_info(1, "enter_the_east.mp3", 0.5);
add_bgm_info(2, "enter_the_east.mp3", 0.5);
add_bgm_info(54, "ancient_pyramid.mp3", 0.5);
add_bgm_info(67, "nuriki_95-100.mp3", 0.5);

set_bgm_volume_enable();

dofile(get_locale_base_path().."/BlueDragon.lua")
dofile(get_locale_base_path().. "/quest/GFquestlib.lua")

