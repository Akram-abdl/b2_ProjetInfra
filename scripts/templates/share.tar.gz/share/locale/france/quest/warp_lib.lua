--[[
    Inizializes:
        The 'Warp' class.
]]
Warp = {};
--[[
    Returns:
        The full warp config.
    Structure:
        [section_key] = {
            ["section"] = "The section name", 
            ["data"] = {
                {["name"] = "The name of the first map", ["warp"] = {[1] = {x_shinsoo, y_shinsoo}, [2] = {x_chunjo, y_chunjo}, [3] = {x_jinno, y_jinno}}, ["price"] = the warp cost, ["min_level"] = the minimum level to enter the map, ["max_level"] = the maximum level to enter the map},
                {["name"] = "The name of the second map", ["warp"] = {[1] = {x_shinsoo, y_shinsoo}, [2] = {x_chunjo, y_chunjo}, [3] = {x_jinno, y_jinno}}, ["price"] = the warp cost, ["min_level"] = the minimum level to enter the map, ["max_level"] = the maximum level to enter the map},
                ..
            }
        },
]]


Warp.GetConfig = function()
    local config = {}
    local npcVnum = npc.get_vnum()
    if npcVnum == 9004 then
        config = {
            [1] = {
                ["section"] = "Villages", 
                ["data"] = {
                    {["name"] = "Empire Neutre", ["warp"] = {[1] = {["x"] = 428, ["y"] = 350}, [2] = {["x"] = 428, ["y"] = 350}, [3] = {["x"] = 428, ["y"] = 350}}, ["price"] = 1000, ["min_level"] = 1, ["max_level"] = 120},
                    {["name"] = "Empire Minsoo", ["warp"] = {[1] = {["x"] = 639, ["y"] = 3200}, [2] = {["x"] = 639, ["y"] = 3200}, [3] = {["x"] = 639, ["y"] = 3200}}, ["price"] = 10000, ["min_level"] = 70, ["max_level"] = 120},
                    {["name"] = "Empire Jinsa",  ["warp"] = {[1] = {["x"] = 384,  ["y"] = 4736}, [2] = {["x"] = 384,  ["y"] = 4736}, [3] = {["x"] = 384,  ["y"] = 4736}}, ["price"] = 10000, ["min_level"] = 70, ["max_level"] = 120}
                }
            },
            [2] = {
                ["section"] = "Maps neutres",
                ["data"] = {
                    {["name"] = "30-40",      ["warp"] = {[1] = {["x"] = 3461,  ["y"] = 143}, [2] = {["x"] = 3461,  ["y"] = 143}, [3] = {["x"] = 3461,  ["y"] = 143}}, ["price"] = 11000, ["min_level"] = 30, ["max_level"] = 120},
                    {["name"] = "40-50",      ["warp"] = {[1] = {["x"] = 4488,   ["y"] = 142}, [2] = {["x"] = 4488,   ["y"] = 142}, [3] = {["x"] = 4488,   ["y"] = 142}}, ["price"] = 12000, ["min_level"] = 40, ["max_level"] = 120},
                    {["name"] = "50-60",       ["warp"] = {[1] = {["x"] = 4508,  ["y"] = 1167}, [2] = {["x"] = 4508,  ["y"] = 1167}, [3] = {["x"] = 4508,  ["y"] = 1167}}, ["price"] = 13000, ["min_level"] = 50, ["max_level"] = 120},
                    {["name"] = "60-70",         ["warp"] = {[1] = {["x"] = 6395,  ["y"] = 31}, [2] = {["x"] = 6395,  ["y"] = 31}, [3] = {["x"] = 6395,  ["y"] = 31}}, ["price"] = 14000, ["min_level"] = 60, ["max_level"] = 120}
                }
            }
        };
    elseif npcVnum == 9005 then
        config = {
            [1] = {
                ["section"] = "Villages", 
                ["data"] = {
                    {["name"] = "Empire Neutre", ["warp"] = {[1] = {["x"] = 428, ["y"] = 350}, [2] = {["x"] = 428, ["y"] = 350}, [3] = {["x"] = 428, ["y"] = 350}}, ["price"] = 1000, ["min_level"] = 1, ["max_level"] = 120},
                    {["name"] = "Empire Minsoo", ["warp"] = {[1] = {["x"] = 639, ["y"] = 3200}, [2] = {["x"] = 639, ["y"] = 3200}, [3] = {["x"] = 639, ["y"] = 3200}}, ["price"] = 10000, ["min_level"] = 70, ["max_level"] = 120},
                    {["name"] = "Empire Jinsa",  ["warp"] = {[1] = {["x"] = 384,  ["y"] = 4736}, [2] = {["x"] = 384,  ["y"] = 4736}, [3] = {["x"] = 384,  ["y"] = 4736}}, ["price"] = 10000, ["min_level"] = 70, ["max_level"] = 120}
                }
            },
            [2] = {
                ["section"] = "Maps neutres",
                ["data"] = {
                    {["name"] = "70-75",      ["warp"] = {[1] = {["x"] = 1618,  ["y"] = 3397}, [2] = {["x"] = 1618,  ["y"] = 3397}, [3] = {["x"] = 1618,  ["y"] = 3397}}, ["price"] = 15000, ["min_level"] = 70, ["max_level"] = 120},
                    {["name"] = "75-80",        ["warp"] = {[1] = {["x"] = 2495,  ["y"] = 4803}, [2] = {["x"] = 2495,  ["y"] = 4803}, [3] = {["x"] = 2495,  ["y"] = 4803}}, ["price"] = 16000, ["min_level"] = 75, ["max_level"] = 120},
                    {["name"] = "80-85",      ["warp"] = {[1] = {["x"] = 3648,   ["y"] = 2962}, [2] = {["x"] = 3648,   ["y"] = 2962}, [3] = {["x"] = 3648,   ["y"] = 2962}}, ["price"] = 17000, ["min_level"] = 80, ["max_level"] = 120},
                    {["name"] = "85-90",          ["warp"] = {[1] = {["x"] = 5025,  ["y"] = 3595}, [2] = {["x"] = 5025,  ["y"] = 3595}, [3] = {["x"] = 5025,  ["y"] = 3595}}, ["price"] = 18000, ["min_level"] = 85, ["max_level"] = 120},
                    {["name"] = "90-95",         ["warp"] = {[1] = {["x"] = 6076,  ["y"] = 2921}, [2] = {["x"] = 6076,  ["y"] = 2921}, [3] = {["x"] = 6076,  ["y"] = 2921}}, ["price"] = 19000, ["min_level"] = 90, ["max_level"] = 120},
                    {["name"] = "95-100",         ["warp"] = {[1] = {["x"] = 5537,  ["y"] = 1450}, [2] = {["x"] = 5537,  ["y"] = 1450}, [3] = {["x"] = 5537,  ["y"] = 1450}}, ["price"] = 20000, ["min_level"] = 95, ["max_level"] = 120}
                }
            }
        };
    end
    return config;
end -- function
--[[
    Returns:
        An array containing all the existent Warp.GetConfigs' ["section"].
]]
Warp.GetSection = function()
    local section = {};
    local config = Warp.GetConfig();
    for _, data in ipairs(config) do
        table.insert(section, data["section"]);
    end -- for
    return section;
end -- function
--[[
    Returns:
        name, coordinates, price and minimum level of the selected map.
    Explanation:
        The selected map is given by the number inserted in the 'section' argument
        which gets the section_key from the Warp.GetConfig array. (see the Warp.GetConfigs' structure)
]]
Warp.GetBuildSection = function(section)
    local names, warp, price, min_level, max_level = {}, {}, {}, {}, {};
    local data = Warp.GetConfig()[section]["data"];
    for _, subdata in ipairs(data) do
        table.insert(names, subdata["name"]);
        table.insert(warp,  subdata["warp"][pc.get_empire()]);
        table.insert(price, subdata["price"]);
        table.insert(min_level, subdata["min_level"]);
        table.insert(max_level, subdata["max_level"]);
    end -- for
    return names, warp, price, min_level, max_level;
end -- function