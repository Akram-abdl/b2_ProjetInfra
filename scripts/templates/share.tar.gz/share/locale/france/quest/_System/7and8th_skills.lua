quest new7and8th_skills begin
    state start begin
		when 50514.use begin
			say_title(item_name(50514))
			say("")
			if pc.get_skill_group() == 0 then
				say("Vous n'avez pas encore commenc� un apprentissage.")
				return
			end
			
			local check_learned = 0
			local help_skill_list = {
										{{236}, {240},},
										{{237}, {241},},
										{{238}, {242},},
										{{239}, {243},},
										-- {{244},},
			}
			
			local skill_list = help_skill_list[pc.get_job() + 1][pc.get_skill_group()]
			for i = 1, table.getn(skill_list) do
				skill_vnum = skill_list[i]
				if pc.get_skill_level(skill_vnum) > 0 then
					check_learned = 1
				end
			end
			
			if check_learned == 1 then
				say("Vous avez d�j� appris une des techniques de renforcement.")
				return
			end
			
			help_skill_list_name = {
								[236] = "Bonus Moulinet de l'�p�e",
								[237] = "Bonus Embuscade",
								[238] = "Bonus Toucher br�lant",
								[239] = "Bonus Dragon chassant",
								[240] = "Bonus Attaque de l'esprit",
								[241] = "Bonus Fl�che de feu",
								[242] = "Bonus Attaque des t�n�bres",
								[243] = "Bonus Invocation de foudre"
								-- [244] = "Bonus Souffle de loup"
			}
			
			local skill_vnum_list = {}
			local skill_name_list = {}
			for i = 1, table.getn(skill_list) do
				skill_vnum = skill_list[i]
				if pc.get_skill_level(skill_vnum) < 1 then
					table.insert(skill_vnum_list, skill_vnum)
					table.insert(skill_name_list, help_skill_list_name[skill_vnum])
				end
			end
			
			if table.getn(skill_vnum_list) == 0 then
				say("Il n'y a pas de comp�tences de renforcement disponibles.")
				return
			end
			
			table.insert(skill_name_list, "Annuler")
			say("Ce livre ancien semble tr�s puissant! C'est")
			say("la cl� de toutes comp�tences. Mais il faut d'abord")
			say("d�cider! Les combattants ne peuvent ma�triser qu'une seule comp�tence.")
			say("Choisis sagement!")
			local i = select_table(skill_name_list)
			if i == table.getn(skill_name_list)then
				return
			end
			
			local name = skill_name_list[i]
			local vnum = skill_vnum_list[i]
			say_title(item_name(50514))
			say("")
			say(string.format("Vous choisissez d'apprendre %s.", name))
			say("Vous �tes s�r de votre d�cision?")
			local confirm = select("Oui", "Non")
			if confirm == 1 then
				pc.remove_item(item.get_vnum(), 1)
				pc.set_skill_level(vnum, 1)
				return
			end
			
			return
		end
		
		when 50515.use begin
			say_title(item_name(50515))
			say("")
			if pc.get_skill_group() == 0 then
				say("Vous n'avez pas encore commenc� un apprentissage.")
				return
			end
			
			local check_learned = 0
			-- local anti_skill_list = {221, 222, 223, 224, 225, 226, 227, 228, 229}
			local anti_skill_list = {221, 222, 223, 224, 225, 226, 227, 228}
			for i = 1, table.getn(anti_skill_list) do
				skill_vnum = anti_skill_list[i]
				if pc.get_skill_level(skill_vnum) > 0 then
					check_learned = 1
				end
			end
			
			if check_learned == 1 then
				say("Vous avez d�j� appris une des techniques de Parades.")
				return
			end
			
			anti_skill_list_name = {
								[221] = "Parade Moulinet de l'�p�e",
								[222] = "Parade Embuscade",
								[223] = "Parade Toucher br�lant",
								[224] = "Parade Dragon chassant",
								[225] = "Parade Attaque de l'esprit",
								[226] = "Parade Fl�che de feu",
								[227] = "Parade Attaque des t�n�bres",
								[228] = "Parade Invocation de foudre"
								-- [229] = "Parade Souffle de loup"
			}
			
			local skill_vnum_list = {}
			local skill_name_list = {}
			for i = 1, table.getn(anti_skill_list) do
				skill_vnum = anti_skill_list[i]
				if pc.get_skill_level(skill_vnum) < 1 then
					table.insert(skill_vnum_list, skill_vnum)
					table.insert(skill_name_list, anti_skill_list_name[skill_vnum])
				end
			end
			
			if table.getn(skill_vnum_list) == 0 then
				say("Il n'y a pas de comp�tences de parade disponibles.")
				return
			end
			
			table.insert(skill_name_list, "Annuler")
			say("Ce livre ancien semble tr�s puissant! C'est")
			say("la cl� de toutes comp�tences. Mais il faut d'abord")
			say("decider! Les combattants ne peuvent ma�triser qu'une seule comp�tence.")
			say("Choisis sagement!")
			local i = select_table(skill_name_list)
			if i == table.getn(skill_name_list)then
				return
			end
			
			local name = skill_name_list[i]
			local vnum = skill_vnum_list[i]
			say_title(item_name(50515))
			say("")
			say(string.format("Vous choisissez d'apprendre %s.", name))
			say("Vous �tes s�r de votre d�cision?")
			local confirm = select("Oui", "Non")
			if confirm == 1 then
				pc.remove_item(item.get_vnum(), 1)
				pc.set_skill_level(vnum, 1)
				return
			end
			
			return
		end
		
		when 50525.use begin
			say_title(item_name(50525))
			say("")
			if pc.get_skill_group() == 0 then
				say("Vous n'avez pas encore commenc� un apprentissage.")
				return
			end
			
			if get_time() < pc.getqf("next_time") then
				if not pc.is_skill_book_no_delay() then
					say("Lorsque votre formation est termin�e, vous devez")
					say("vous reposez entre 12 � 24h.")
					return
				end
			end
			
			GRAND_MASTER_SKILL_LEVEL = 30
			PERFECT_MASTER_SKILL_LEVEL = 40
			local check_learned = 0
			-- local new_skill_list = {221, 222, 223, 224, 225, 226, 227, 228, 229, 236, 237, 238, 239, 240, 241, 242, 243, 244}
			local new_skill_list = {221, 222, 223, 224, 225, 226, 227, 228, 236, 237, 238, 239, 240, 241, 242, 243}
			for i = 1, table.getn(new_skill_list) do
				skill_vnum = new_skill_list[i]
				if pc.get_skill_level(skill_vnum) >= GRAND_MASTER_SKILL_LEVEL and pc.get_skill_level(skill_vnum) < PERFECT_MASTER_SKILL_LEVEL then
					check_learned = 1
				end
			end
			
			if check_learned == 0 then
				say("Aucune comp�tence n'a encore �t� acquise gr�ce � la comp�tence")
				say("Formation des grands ma�tres.")
				return
			end
			
			new_skill_list_name = {
								[221] = "Parade Moulinet de l'�p�e",
								[222] = "Parade Embuscade",
								[223] = "Parade Toucher br�lant",
								[224] = "Parade Dragon chassant",
								[225] = "Parade Attaque de l'esprit",
								[226] = "Parade Fl�che de feu",
								[227] = "Parade Attaque des t�n�bres",
								[228] = "Parade Invocation de foudre",
								-- [229] = "Parade Souffle de loup",
								[236] = "Bonus Moulinet de l'�p�e",
								[237] = "Bonus Embuscade",
								[238] = "Bonus Toucher br�lant",
								[239] = "Bonus Dragon chassant",
								[240] = "Bonus Attaque de l'esprit",
								[241] = "Bonus Fl�che de feu",
								[242] = "Bonus Attaque des t�n�bres",
								[243] = "Bonus Invocation de foudre"
								-- [244] = "Bonus Souffle de loup"
			}
			
			local skill_vnum_list = {}
			local skill_name_list = {}
			for i = 1, table.getn(new_skill_list) do
				skill_vnum = new_skill_list[i]
				if pc.get_skill_level(skill_vnum) >= GRAND_MASTER_SKILL_LEVEL and pc.get_skill_level(skill_vnum) < PERFECT_MASTER_SKILL_LEVEL then
					table.insert(skill_vnum_list, skill_vnum)
					table.insert(skill_name_list, new_skill_list_name[skill_vnum])
				end
			end
			
			if table.getn(skill_vnum_list) == 0 then
				say("Il n'y a pas de parade ou de renforcement des comp�tences disponibles.")
				return
			end
			
			say("Quand vous perdez vos (Bon/Mauvais) points pendant")
			say("la formation, il est possible que vous puissiez")
			say("D�class�, m�me sous le niveau d'un Ronin.")
			say("")
			say("Voulez-vous continuez")
			local s = select("Oui", "Non")	
			if s == 2 then
				return
			end
			
			say_title(item_name(50525))
			say("")
			say("Choisissez la comp�tence que vous voulez apprendre:")
			table.insert(skill_name_list, "Annuler")
			local i = select_table(skill_name_list)
			if i == table.getn(skill_name_list)then
				return
			end
			
			local name = skill_name_list[i]
			local vnum = skill_vnum_list[i]
			local level = pc.get_skill_level(vnum)
			local cur_alignment = pc.get_real_alignment()
			local need_alignment = 1000 + 500 * (level - 30)
			
			say_title(item_name(50525))
			say("")
			if cur_alignment <- 19000+need_alignment then
				say_reward("Vous n'avez pas assez de grade,")
				say_reward("pour l'entra�nement grand ma�tres.")
				return
			end
			
			if get_time() < pc.getqf("next_time") then
				if pc.is_skill_book_no_delay() then
					pc.remove_skill_book_no_delay()
				else
					say("Lorsque votre formation est termin�e, vous devez")
					say("vous reposez entre 12 � 24h.")
				end
			end
			
			say(string.format("Vous choisissez d'apprendre %s.", name))
			say("Vous �tes s�r de votre d�cision?")
			local confirm = select("Oui", "Non")
			if confirm == 1 then
				pc.setqf("next_time", get_time() + 60 * 60 * math.random(12, 24))
				
				say_title(item_name(50525))
				say("")
				if pc.learn_grand_master_skill(vnum) then
					if pc.get_skill_level(vnum) == 40 then
						say(string.format("%s est maintenant en Ma�tre parfait.", name))
					else
						say(string.format("Vous avez augment� %s a G%d.", name, level-30+1+1))
					end
					
					say("Mon corps est plein de pouvoir. Quelque chose vient l�!")
					say("Vous avez termin� un niveau plus �lev� de formation avec succ�s.")
				else
					pc.change_alignment(-number(need_alignment / 3, need_alignment / 2))
					say("�a n'a pas march�. Zut!")
				end
				
				pc.remove_item(item.get_vnum(), 1)
			end
			
			return
		end
		
		when 71000.use begin
			say_title(item_name(71000))
			say("")
			if pc.get_skill_group() == 0 then
				say("Vous n'avez pas encore commenc� un apprentissage.")
				return
			end
			
			local check_learned = 0
			-- local new_skill_list = {221, 222, 223, 224, 225, 226, 227, 228, 229, 236, 237, 238, 239, 240, 241, 242, 243, 244}
			local new_skill_list = {221, 222, 223, 224, 225, 226, 227, 228, 236, 237, 238, 239, 240, 241, 242, 243}
			for i = 1, table.getn(new_skill_list) do
				skill_vnum = new_skill_list[i]
				if pc.get_skill_level(skill_vnum) > 0 then
					check_learned = 1
				end
			end
			
			if check_learned == 0 then
				say("Il n'y a pas de parade ou de renforcement des comp�tences disponibles.")
				return
			end
			
			say("Vous oublierez tout ce que vous avez appris sur le bonus")
			say("et parade, �tes-vous s�r de votre d�cision?")
			local confirm = select("Oui", "Non")
			if confirm == 1 then
				for i = 1, table.getn(new_skill_list) do
					skill_vnum = new_skill_list[i]
					if pc.get_skill_level(skill_vnum) > 0 then
						pc.set_skill_level(skill_vnum, 0)
					end
				end
				
				pc.remove_item(item.get_vnum(), 1)
			end
			
			return
		end
    end
end