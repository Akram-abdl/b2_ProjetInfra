quest slime_dungeon begin
	state start begin
	--QUEST FUNCTIONS
		function settings()
			return
			{
				["slime_dung_index"] = 50,
				["slime_dung_warp"] = {1197700, 25300},
				["out_pos"] = {11078, 16380},
				["level_check"] = {
					["minimum"] = 70,
					["maximum"] = 120
				},
				["slime_metin"] = 4030,
				["slime_metin_pos"] = {245, 256},
				["keys"] = {30801, 30802},
				["slime_queen"] = 4031,
				["slime_queen_pos"] = {285, 260},
				["item_reward"] = {295, 3215, 2155, 1175, 5115, 7165},
			};
		end
		
		function get_regens(level)
			local regens = {
				[1] = "data/dungeon/slime_dungeon/regen_1.txt",
				[2] = "data/dungeon/slime_dungeon/regen_2.txt",
				[3] = "data/dungeon/slime_dungeon/regen_3.txt"};
			return d.regen_file(regens[level])
		end
		
		function is_slimed()
			local pMapIndex = pc.get_map_index();
			local data = slime_dungeon.settings();
			local map_index = data["slime_dung_index"];

			return pc.in_dungeon() and pMapIndex >= map_index*10000 and pMapIndex < (map_index+1)*10000;
		end
		
		function clear_slimedungeon()
			d.clear_regen();
			d.kill_all();
		end
		
		function check_enter()
			addimage(25, 10, "slime_dungeon.tga")
			addimage(230, 150, "thurang.tga")
			say("")
			say("")
			say("")
			say_title(mob_name(4036))
			say("")
			local settings = slime_dungeon.settings()

			if pc.get_level() < settings["level_check"]["minimum"] then
				say("Si vous voulez aller dans la grotte des slimes,")
				say(string.format("vous devez �tre minimum niveau %d", settings["level_check"]["minimum"]))
				say("")
				return
			end
			
			if pc.get_level() > settings["level_check"]["maximum"] then
				say("Si vous voulez aller dans la grotte des slimes,")
				say(string.format("vous devez �tre maximum niveau %d", settings["level_check"]["maximum"]))
				say("")
				return
			end

			say("Une fois le bouton appuy�, vous serez")
			say("t�l�port�s dans le donjon de Slime !")
			say("Faites attention � vous !")
			say("")
			say_reward("Vous n'avez que 15 minutes pour terminer")
			say_reward("tout le donjon !")
			say_reward("Faites vite !")
			wait()
			slime_dungeon.create_dungeon()
		end
				
		function create_dungeon()
			local settings = slime_dungeon.settings()
			
			d.new_jump(settings["slime_dung_index"], settings["slime_dung_warp"][1], settings["slime_dung_warp"][2])
			d.setf("slimedung_level", 1)
			d.spawn_mob(settings["slime_metin"], settings["slime_metin_pos"][1], settings["slime_metin_pos"][2])
			server_timer("slime_dungeon_15minutesleft", 5*60, d.get_map_index())
		end
		--FUNCTIONS END

		--DUNGEON CHECK
		when login begin
			local indx = pc.get_map_index()
			local settings = slime_dungeon.settings()
						
			if indx == settings["slime_dung_index"] then
				if not pc.in_dungeon() then
					warp_to_village()
				end
			end
		end
		
		--MAP ENTER
		--DUNGEON ENTER
		when 4036.chat."Grottes de Slime"  with not slime_dungeon.is_slimed() begin
			local settings = slime_dungeon.settings()
			addimage(25, 10, "slime_dungeon.tga")
			addimage(230, 150, "thurang.tga")
			say("")
			say("")
			say("")
			say_title(mob_name(4036))
			say("")
			say("Bonjour guerrier !")
			say("Je suis Thu-Trang, le gardien de la reine Slime.")
			say("Je suis responsable de ces slimes. Ils n'apparaissent")
			say("pas toujours, mais par chance, ils se sont regroup�s")
			say("dans cette grotte. Nous avons besoin de guerrier")
			say("puissant comme vous !")
			wait()
			addimage(25, 10, "slime_dungeon.tga")
			addimage(230, 150, "thurang.tga")
			say("")
			say("")
			say("")
			say_title(mob_name(4036))
			say("")
			say("�tes-vous assez courageux ?")
			say("Esp�rons que oui, la reine Slime est tr�s")
			say("puissante...")
			say("")
			say_title("Voulez-vous entrer dans la grotte ?")
			if (select ("Oui", "Non") == 1) then
				slime_dungeon.check_enter()
			end
		end
		
		when 4030.kill with slime_dungeon.is_slimed() and d.getf("slimedung_level") == 1 begin
			d.notice("Grotte de Slime: Vous avez d�truit la pierre de Slime !")
			d.notice("Grotte de Slime: Les monstres arrivent !")
			d.notice("Grotte de Slime: Tuez-les tous !")
			d.setf("slimedung_level", 2)
			timer("slime_wave_spawn", 6)
		end
		
		when 4034.chat."Ouverture du sceau" with slime_dungeon.is_slimed()  and d.getf("slimedung_level") == 3 begin
			local settings = slime_dungeon.settings()
			addimage(25, 10, "slime_dungeon.tga")
			say("")
			say("")
			say("")
			say("Cette pierre a un pouvoir magique. Il y a un")
			say("petit creux ici, je pense que nous devons verser")
			say("du slime pour reboucher le trou.")
			say("Essayons !")
			wait()
			d.setf("slimedung_level", 4)
			timer("slime_wave_spawn", 1)
		end
		
		when 4030.kill with slime_dungeon.is_slimed() and d.getf("slimedung_level") == 4 begin
			local settings = slime_dungeon.settings()
			if d.getf("slime_stone") == 1 then
				d.notice("Grotte de Slime: 3 metins de Slime restantes !")
				d.setf("slime_stone", 2)
			elseif d.getf("slime_stone") == 2 then
				d.notice("Grotte de Slime: 2 metins de Slime restantes !")
				d.setf("slime_stone", 3)
			elseif d.getf("slime_stone") == 3 then
				d.notice("Grotte de Slime: 1 metin de Slime restante !")
				d.setf("slime_stone", 4)
			elseif d.getf("slime_stone") == 4 then
				d.notice("Grotte de Slime: Vous avez d�truit toutes les pierres metin !")
				d.notice("Grotte de Slime: R�cup�rer la gourde et remplissez-la de slime !")
				d.setf("slime_stone", 0)
				d.setf("slimedung_level", 5)
				game.drop_item(settings["keys"][1], 1)
			end
		end
		
		when 4035.take with item.get_vnum() == 30801 and slime_dungeon.is_slimed() and d.getf("slimedung_level") == 5 begin
			local settings = slime_dungeon.settings()
			pc.remove_item(settings["keys"][1], 1)
			pc.give_item2(settings["keys"][2], 1)
			npc.purge()
			d.notice("Grotte de Slime: Maintenant, remplissez le trou avec le slime !")
			d.setf("slimedung_level", 6)
		end
		
		when 4034.take with item.get_vnum() == 30802 and slime_dungeon.is_slimed() and d.getf("slimedung_level") == 6 begin
			local settings = slime_dungeon.settings()
			pc.remove_item(settings["keys"][2], 1)
			npc.kill(4034)
			slime_dungeon.clear_slimedungeon()
			d.notice("Grotte de Slime: La force mal�fique est partie !")
			d.notice("Grotte de Slime: Attention des monstres arrivent !")
			d.setf("slimedung_level", 7)
			timer("slime_wave_spawn", 5)
		end
		
		when 4031.kill with slime_dungeon.is_slimed() and d.getf("slimedung_level") == 8 begin
			slime_dungeon.clear_slimedungeon()
			d.notice("Grotte de Slime: Vous avez termin� le donjon avec succ�s !")
			d.notice("Grotte de Slime: Vous serez t�l�port�s hors du donjon dans 2 minutes.")

			local settings = slime_dungeon.settings();
			local reward = settings["item_reward"];
			local randomNumber = number(1, table.getn(reward));

			d.drop(tonumber(reward[randomNumber]))

			server_timer("slime_dungeon_is_done", 115, d.get_map_index())
			d.setf("slimedung_level", 9)
		end

		-- SPAWN OR NOTICE TIMER
		when slime_wave_spawn.timer begin
		if d.getf("slimedung_level") == 2 then
			slime_dungeon.get_regens(1)
			loop_timer("slime_wave_kill", 15);
		elseif d.getf("slimedung_level") == 4 then
			d.setf("slime_stone", 1)
			slime_dungeon.get_regens(3)
			d.notice("Grotte de Slime: D�truisez toutes les pierres metin, et trouvez la gourde !")
		elseif d.getf("slimedung_level") == 7 then
			slime_dungeon.get_regens(1)
			loop_timer("slime_wave_kill", 15);
		elseif d.getf("slimedung_level") == 8 then
				local settings = slime_dungeon.settings()
				d.spawn_mob(settings["slime_queen"], settings["slime_queen_pos"][1], settings["slime_queen_pos"][2])
			end
		end

		-- LOOP TIMER FOR KILLING MONSTERS
		when slime_wave_kill.timer begin
			local settings = slime_dungeon.settings()
			if d.getf("slimedung_level") == 2 then
				if (d.count_monster() == 0) then
					slime_dungeon.clear_slimedungeon()
					cleartimer("wave_kill");
					d.setf("slimedung_level", 3)
					d.notice("Grotte de Slime: Vous avez tu� tous les monstres !");
					d.notice("Grotte de Slime: Une pierre de sceau vient d'appara�tre !");
					d.notice("Grotte de Slime: Allons voir �a de plus pr�s !");
					slime_dungeon.get_regens(2)
				else
					d.notice(string.format("Grotte de Slime: Vous devez encore tuer %d monstres pour continuer..", d.count_monster()));
				end
			elseif d.getf("slimedung_level") == 7 then
				if (d.count_monster() == 0) then
					cleartimer("wave_kill");
					d.setf("slimedung_level", 8)
					d.notice("Grotte de Slime: Vous avez tu� tous les monstres !");
					d.notice("Grotte de Slime: La reine Slime arrive !!");
					timer("slime_wave_spawn", 5)
				else
					d.notice(string.format("Grotte de Slime: Vous devez encore tuer %d monstres pour continuer..", d.count_monster()));
				end
			end
		end
		
		when slime_dungeon_15minutesleft.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Grotte de Slime: !!!!! Seulement 10 minutes restantes !!!!!")
				server_timer("slime_dungeon_5minutesleft", 5*60, d.get_map_index())
			end
		end
		
		when slime_dungeon_5minutesleft.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Grotte de Slime: !!!!! Seulement 5 minutes restantes !!!!!")
				d.notice("Grotte de Slime: Vous manquez de temps !")
				server_timer("slime_dungeon_1minutesleft", 4*60, d.get_map_index())
			end
		end
		
		when slime_dungeon_1minutesleft.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Grotte de Slime: !!!!! Seulement 1 minute restante !!!!!")
				d.notice("Grotte de Slime: C'est bient�t la fin, d�p�chez-vous !")
				server_timer("slime_dungeon_0minutesleft", 60, d.get_map_index())
			end
		end
		
		when slime_dungeon_0minutesleft.server_timer begin
			if d.select(get_server_timer_arg()) then
				server_timer("slime_dungeon_is_done", 1, d.get_map_index())
			end
		end
		
		when slime_dungeon_is_done.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Grotte de Slime: T�l�portation !!")
				slime_dungeon.clear_slimedungeon()
				d.set_warp_location(4, 4174, 2140)
			end
			
			server_timer("final_exit_slime", 2, d.get_map_index())
		end
		
		when final_exit_slime.server_timer begin
			if d.select(get_server_timer_arg()) then								
				d.exit_all()
			end
		end									
	end
end
