quest duratus_dungeon begin
	state start begin
	function settings()
		return
		{
			["duratus_dungeon_index"] = 50,
			["duratus_dungeon_warp"] = {292, 6802},
			["duratus_dungeon_index_out"] = 1,
			["out_pos"] = {428, 350},
			["level_check"] = {
				["minimum"] = 100,
				["maximum"] = 200
			},
			["pass"] = 30750,
			["items"] = {30751, 30752, 30753},
			
			["door"] = 9268, 				
			["door_pos"] = {292, 380, 5},
			["bombox"] = 9264, 				
			["bombox_pos"] = {291, 376, 5},
			["trollboss"] = 4030, 				
			["trollboss_pos"] = {289, 279},
			["main_npc"] = 4039, 				
			["main_npc_pos"] = {292, 164, 5},
			["duratus"] = 4032, 				
			["duratus_pos"] = {299, 479, 5},
		};
	end	
	--------PARTY AND ENTER
	
	function is_duratused()
		local pMapIndex = pc.get_map_index();
		local data = duratus_dungeon.settings();
		local map_index = data["duratus_dungeon_index"];

		return pc.in_dungeon() and pMapIndex >= map_index*10000 and pMapIndex < (map_index+1)*10000;
	end
	
	function clear_duratusdungeon()
		d.clear_regen();
		d.kill_all();
	end
	
	function clear_duratustimers()
		clear_server_timer("duratus_dungeon_wave_kill", get_server_timer_arg())
		clear_server_timer("duratus_dungeon_20min_left", get_server_timer_arg())
		clear_server_timer("duratus_dungeon_10min_left", get_server_timer_arg())
		clear_server_timer("duratus_dungeon_5min_left", get_server_timer_arg())
		clear_server_timer("duratus_dungeon_1min_left", get_server_timer_arg())
		clear_server_timer("duratus_dungeon_0min_left", get_server_timer_arg())
		clear_server_timer("duratus_dungeon_final", get_server_timer_arg())
	end
	
	function check_enter()
		addimage(25, 10, "duratus_bg_01.tga")
		addimage(225, 150, "duratus_npc.tga")
		say("")
		say("")
		say("")
		say_title(mob_name(4039))
		local settings = duratus_dungeon.settings()
		
		if ((get_global_time() - pc.getf("duratus_dungeon","exit_duratus_dungeon_time")) < 60*60) then
		
			local remaining_wait_time = (pc.getf("duratus_dungeon","exit_duratus_dungeon_time") - get_global_time() + 60*60)
			say("You have to wait until you can enter the dungeon again.")
			say_reward("You can enter Duratus dugeon again in: "..get_time_remaining(remaining_wait_time)..'[ENTER]')
			return
		end
		
		if party.is_party() then			
			if not party.is_leader() then
				say_reward("Let me talk with your leader first.")
				return
			end

			if party.get_near_count() < 2 then
				say_reward("Your group must have atleast 2 players and")
				say_reward("they have to be around.")
				say_reward("Otherwise i can not let you there. ")
				return false;
			end
			
			local levelCheck = true
			local passCheck = true
			local MemberHaveLowLevel = {}
			local MemberHaveHighLevel = {}
			local MemberHaveNoTicket = {}
			local pids = {party.get_member_pids()}
			
			if not party.is_map_member_flag_lt("exit_duratus_dungeon_time", get_global_time() - 60 * 60 ) then
				say_reward("Some people of the group still")
				say_reward("have to wait.")
				return false;
			end
						
			for i, pid in next, pids, nil do
				q.begin_other_pc_block(pid)
				if pc.get_level() < settings["level_check"]["minimum"] then
					table.insert(MemberHaveLowLevel, pc.get_name())
					levelCheck = false
				end

				q.end_other_pc_block()
			end

			if not levelCheck then
				say_reward("If you want to enter the dungeon,")
				say_reward("every each member must have atleast level 30.")
				say_reward("")
				say_reward("These members has not required level: ")
				for i, n in next, MemberHaveLowLevel, nil do
					say_title("- "..n)
				end
				return
			end
			
			for i, pid in next, pids, nil do
				q.begin_other_pc_block(pid)
				if pc.get_level() > settings["level_check"]["maximum"] then
					table.insert(MemberHaveHighLevel, pc.get_name())
					levelCheck = false
				end

				q.end_other_pc_block()
			end

			if not levelCheck then
				say_reward("If you want to enter the dungeon,")
				say_reward("every each member must have maximum level 65.")
				say("")
				say_reward("Next members do not have enough level:")
				for i, n in next, MemberHaveHighLevel, nil do
					say_title("- "..n)
				end
				return
			end
			
			for i, pid in next, pids, nil do
				q.begin_other_pc_block(pid)
				if pc.count_item(settings.pass) < 1 then
					table.insert(MemberHaveNoTicket, pc.get_name())
					passCheck = false
				end

				q.end_other_pc_block()
			end

			if not passCheck then
				say_reward("If you want to enter the dungeon,")
				say_reward("every each member must have:")
				say_item("Duratus magic stone", settings["pass"], "")
				say("")
				say_reward("These members don't have the")
				say_reward("Duratus magic stone:")
				for i, n in next, MemberHaveNoTicket, nil do
					say_title("- "..n)
				end
				return
			end
	
		else
		
			if ((get_global_time() - pc.getf("duratus_dungeon","exit_duratus_dungeon_time")) < 60*60) then
			
				local remaining_wait_time = (pc.getf("duratus_dungeon","exit_duratus_dungeon_time") - get_global_time() + 60*60)
				say("You have to wait until you can enter the dungeon again.")
				say_reward("You can go there again in: "..get_time_remaining(remaining_wait_time)..'[ENTER]')
				return
			end
			
			if (pc.get_level() < settings["level_check"]["minimum"]) then
				say(string.format("The minimum level to enter the dungeon is %d.", settings["level_check"]["minimum"]))
				return false;
			end
			
			if (pc.get_level() > settings["level_check"]["maximum"]) then
				say(string.format("The maximum level to enter the dungeon is %d.", settings["level_check"]["maximum"]))
				return false;
			end
			
			if (pc.count_item(settings["pass"]) < 1) then
				say_reward("If you want to enter the dungeon")
				say_reward("you must have ")
				say_item("Duratus magic stone", settings["pass"], "")
				return false;
			end
		end
		
		return true;
	end
	
	------------CREATE DUNGEON
	function create_dungeon()
		local setting = duratus_dungeon.settings()
		local pids = {party.get_member_pids()}
		
		if party.is_party() then
			for i, pid in next, pids, nil do
				q.begin_other_pc_block(pid)
				pc.remove_item(setting["pass"], 1)
				q.end_other_pc_block()
			end
			d.new_jump_party(setting["duratus_dungeon_index"], setting["duratus_dungeon_warp"][1], setting["duratus_dungeon_warp"][2])
		else
			pc.remove_item(setting["pass"], 1)
			d.new_jump(setting["duratus_dungeon_index"], setting["duratus_dungeon_warp"][1]*100, setting["duratus_dungeon_warp"][2]*100)
		end

		d.spawn_mob_dir(setting["door"], setting["door_pos"][1], setting["door_pos"][2], setting["door_pos"][3])
		d.spawn_mob_dir(setting["bombox"], setting["bombox_pos"][1], setting["bombox_pos"][2], setting["bombox_pos"][3])
		d.spawn_mob_dir(setting["main_npc"], setting["main_npc_pos"][1], setting["main_npc_pos"][2], setting["main_npc_pos"][3])
		d.setf("duratus_dungeon_level", 1)
		server_timer("duratus_dungeon_20min_left", 5*60, d.get_map_index())
	end
		
-----------LOGIN IN DUNGEON [OUT COORDS SETTING]
		when login with duratus_dungeon.is_duratused() begin
			local settings = duratus_dungeon.settings()
						
			d.set_warp_location(settings["duratus_dungeon_index_out"], settings["out_pos"][1], settings["out_pos"][2]);
			if not pc.is_gm() then
				if not pc.in_dungeon() then
					pc.warp(settings["duratus_dungeon_index_out"], settings["out_pos"][1]*100, settings["out_pos"][2]*100)
				end
			end
		end


		--DUNGEON ENTER
		when 4039.chat."Duratus dungeon" with not duratus_dungeon.is_duratused() begin
			local settings = duratus_dungeon.settings()
			addimage(25, 10, "duratus_bg_01.tga")
			addimage(225, 150, "duratus_npc.tga")
			say("")
			say("")
			say("")
			say_title(mob_name(4039))
			say("")
			say("Hello warrior!")
			say("I came from duratus caves.")
			say("We were living there in peace, digging")
			say("gold and crystals, everythig was fine.")
			say("Until we found a wierd crystal.")
			say("From that day everything is wrong.")
			say("Some evil power is there and all")
			say("creatures are obsessed by that power.")
			wait()
			addimage(25, 10, "duratus_bg_01.tga")
			addimage(225, 150, "duratus_npc.tga")
			say("")
			say("")
			say("")
			say_title(mob_name(4039))
			say("")
			say("There is no more gold, no crystals, nothing.")
			say("The biggest problem is duratus, the main")
			say("beast. It killed 80% of duratus")
			say("population.")
			say("")
			say("Can you help us?")
			if (select ("Yes", "No") == 1) then
				if duratus_dungeon.check_enter() then
					say_reward("Be careful, you have onle 20 minutes")
					say_reward("to finish whole dungeon.")
					say_reward("The you will be teleported back here.")
					wait()
					duratus_dungeon.create_dungeon()
				end
			end
		end
		
		---TIME RESET - ONLY FOR GM
		when 4039.chat."Time reset" with pc.is_gm() and not duratus_dungeon.is_duratused() begin
			addimage(25, 10, "duratus_bg_01.tga")
			say("")
			say("")
			say("")
			if select('Reset time','Close') == 2 then return end
			addimage(25, 10, "duratus_bg_01.tga")
			say("")
			say("")
			say("")
			say_title(mob_name(4039))
			say("")
			say("Time has been reseted.")
			pc.setf('duratus_dungeon','exit_duratus_dungeon_time', 0)
			
			-- Dungeon Info
			pc.setqf("rejoin_time", get_time() - 3600)
		end	
-----------------------------------------------------------------------------
---------Dungeon
-----------------------------------------------------------------------------
		when 4039.chat."What now?" with duratus_dungeon.is_duratused() and d.getf("duratus_dungeon_level") == 1 begin
			local settings = duratus_dungeon.settings()
			addimage(25, 10, "duratus_bg_02.tga")
			addimage(225, 150, "duratus_npc.tga")
			say("")
			say("")
			say("")
			say_title(mob_name(4039))
			say("")
			say("They are hiding, and they built a wooden")
			say("wall. You need to get")
			say_item("Explosion crystal", settings["items"][1], "")
			say("")
			say("and destroy the box with bombs")
			say_reward("Good luck, they are coming")
			wait()
			npc.purge()
			d.setf("duratus_dungeon_level", 2)
			server_loop_timer("duratus_dungeon_wave_kill", 15, d.get_map_index())
			d.regen_file("data/dungeon/duratus_dungeon/regen_1a.txt")
		end

		when kill with duratus_dungeon.is_duratused() and not npc.is_pc() begin
			local settings = duratus_dungeon.settings()
			if d.getf("duratus_dungeon_level") == 3 then
				if npc.get_race() == 4031 then ---Metin at first stage
					local kills1 = 3;
					d.setf("duratus_dungeon_metin1a", d.getf("duratus_dungeon_metin1a")+1);
					if (d.getf("duratus_dungeon_metin1a") < kills1) then
						d.notice(string.format("Duratus dungeon: %d stones has left!", kills1-d.getf("duratus_dungeon_metin1a")))
					else
						d.notice("Duratus dungeon: All stones was destroyed!")
						d.notice("Duratus dungeon: Kill the underground troll!")
						d.setf("duratus_dungeon_level", 4)
						d.spawn_mob(settings["trollboss"], settings["trollboss_pos"][1], settings["trollboss_pos"][2])
					end
				end
			elseif d.getf("duratus_dungeon_level") == 4 then  ---Undeground troll on first stage
				if npc.get_race() == 4030 then ---Metin at first stage
					game.drop_item(settings["items"][1], 1)
					d.notice(string.format("Duratus dungeon: You have killed %s !", mob_name(4030)))
					d.notice("Duratus dungeon: Take the crystal and destroy the gate!")
					d.setf("duratus_dungeon_level", 41)
				end
			elseif d.getf("duratus_dungeon_level") == 5 then  ---Killing monsters on 2th floor to open all 4 monumets
				if number(1,110) == 1 then
					game.drop_item(settings["items"][2], 1);
				end
			elseif d.getf("duratus_dungeon_level") == 6 then --- Undeground trolls
				if npc.get_race() == 4030 then 
					local kills2 = 4;
					d.setf("underground_troll", d.getf("underground_troll")+1);
					if (d.getf("underground_troll") < kills2) then
						d.notice(string.format("Duratus dungeon: %d %s has left!", kills2-d.getf("underground_troll"), mob_name(4030)))
					else
						d.notice(string.format("Duratus dungeon: All %s was killed!", mob_name(4030)))
						d.notice("Duratus dungeon: Now destroy all metin stones")
						d.setf("duratus_dungeon_level", 7)
						server_timer("duratus_dungeon_spawner", 5, d.get_map_index())
					end
				end
			elseif d.getf("duratus_dungeon_level") == 7 then ---- 5x metin before final boss
				if npc.get_race() == 4031 then 
					local kills3 = 5;
					d.setf("duratus_dungeon_metin1b", d.getf("duratus_dungeon_metin1b")+1);
					if (d.getf("duratus_dungeon_metin1b") < kills3) then
						d.notice(string.format("Duratus dungeon: %d stones has left!", kills3-d.getf("duratus_dungeon_metin1b")))
					else
						server_timer("duratus_dungeon_spawner", 5, d.get_map_index())
						d.notice("Duratus dungeon: All stones was destroyed!")
						d.notice(string.format("Duratus dungeon: %s is coming!", mob_name(4032)))
						d.setf("duratus_dungeon_level", 8)
					end
				end
			elseif d.getf("duratus_dungeon_level") == 8 then  ---Final boss
				if npc.get_race() == 4032 then 					
					d.notice("Duratus dungeon: You succesfully finished the dungeon!")
					d.notice("Duratus dungeon: You will be teleported out of dungeon in 2 minutes.")
					duratus_dungeon.clear_duratusdungeon()
					duratus_dungeon.clear_duratustimers()
					d.setf("duratus_dungeon_level", 9)
					server_timer("duratus_dungeon_final", 120, d.get_map_index())
				end
			end
		end

		when 9264.take with item.get_vnum() == 30751 and duratus_dungeon.is_duratused() and d.getf("duratus_dungeon_level") == 41 begin 
			local settings = duratus_dungeon.settings()
			pc.remove_item(settings["items"][1], 1)
			duratus_dungeon.clear_duratusdungeon()
			d.setf("duratus_dungeon_level", 5)
			d.regen_file("data/dungeon/duratus_dungeon/regen_2a.txt")
			d.set_regen_file("data/dungeon/duratus_dungeon/regen_2b.txt")
			d.notice("Open all Duratus monuments!")
		end

		when 9269.take with item.get_vnum() == 30752 and duratus_dungeon.is_duratused() and d.getf("duratus_dungeon_level") == 5 begin 
			local settings = duratus_dungeon.settings()
			pc.remove_item(settings["items"][2], 1)
			npc.kill()
			local open = 4;
			d.setf("duratus_monument", d.getf("duratus_monument")+1);
			if (d.getf("duratus_monument") < open) then
				d.notice(string.format("Duratus dungeon: %d monuments has left!", open-d.getf("duratus_monument")))
			else
				duratus_dungeon.clear_duratusdungeon()
				d.notice("Duratus dungeon: All monuments was destroyed!")
				d.setf("duratus_dungeon_level", 6)
				server_timer("duratus_dungeon_spawner", 5, d.get_map_index())
			end
		end
		
		when duratus_dungeon_wave_kill.server_timer begin
			local settings = duratus_dungeon.settings()
			if d.select(get_server_timer_arg()) then
				if d.getf("duratus_dungeon_level") == 2 then
					if d.count_monster() == 0 then
						clear_server_timer("duratus_dungeon_wave_kill", get_server_timer_arg())
						d.setf("duratus_dungeon_level", 3)
						d.notice("Duratus dungeon: You've killed all monsters!")
						d.notice("Duratus dungeon: Now destroy the stones!")
						d.regen_file("data/dungeon/duratus_dungeon/regen_1b.txt")
					else
						d.notice(string.format("Duratus dungeon: You still have to defeat %d monsters to move on.", d.count_monster()));
					end
				end
			end
		end
		
		when duratus_dungeon_spawner.server_timer begin
			local settings = duratus_dungeon.settings()
			if d.select(get_server_timer_arg()) then
				if d.getf("duratus_dungeon_level") == 6 then
					d.regen_file("data/dungeon/duratus_dungeon/regen_2c.txt")
					d.notice("Duratus dungeon: Underground trolls has came!")
					d.notice("Duratus dungeon: Kill them!!")
				elseif d.getf("duratus_dungeon_level") == 7 then
					d.regen_file("data/dungeon/duratus_dungeon/regen_2d.txt")
				elseif d.getf("duratus_dungeon_level") == 8 then
					d.spawn_mob_dir(settings["duratus"], settings["duratus_pos"][1], settings["duratus_pos"][2], settings["duratus_pos"][3])
				end
			end
		end

		when duratus_dungeon_20min_left.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Duratus dungeon: 15 minutes left!!!")
				server_timer("duratus_dungeon_10min_left", 5*60, d.get_map_index())
			end
		end
		
		when duratus_dungeon_10min_left.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Duratus dungeon: 10 minutes left!! Hurry up!")
				server_timer("duratus_dungeon_5min_left", 5*60, d.get_map_index())
			end
		end
		
		when duratus_dungeon_5min_left.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Duratus dungeon: 5 minutes left!! The clock is ticking!!")
				server_timer("duratus_dungeon_1min_left", 4*60, d.get_map_index())
			end
		end
		
		when duratus_dungeon_1min_left.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Duratus dungeon: 1 minute left!! You almost failed!")
				server_timer("duratus_dungeon_0min_left", 60, d.get_map_index())
			end
		end
		
		when duratus_dungeon_0min_left.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Duratus dungeon: The time is up. You will be teleported out of dungeon.")
				server_timer("duratus_dungeon_final", 5, d.get_map_index())
			end
		end
		
		when duratus_dungeon_final.server_timer begin
			if d.select(get_server_timer_arg()) then								
				d.exit_all()
			end
		end
		
		when logout with duratus_dungeon.is_duratused() begin 
			pc.setf("duratus_dungeon","exit_duratus_dungeon_time", get_global_time())
			pc.setqf("duratus_dungeon", get_time() + 3600)
		end
	end
	state __COMPLETE_DURATUS_DUNG__ begin
	end
end	
		
		
