zoneInfo = {
    [1] = {["x"] = 43000, ["y"] = 35200}, -- Coordonn� x et y de la zone 1
    [2] = {["x"] = 63800, ["y"] = 268600} -- Coordonn� x et y de la zone 2
}

-- Exp = exp de (lvl min + 1)/ 4 -- exemple : map 50 lvmin 2, 2+1 = 3 , 1500 / 4 = 375
-- Yang = yang du mob plus fort de la map * 200 
-- Exp2 = produit en croix : 1075 * 50 / 375 = 143
-- Yang2 =  13.3 * yang / 100
 
-- dungeonZoneInfo = {
--     [11] = { ["zone"] = 1, ["reward_exp"] = 375,        ["reward_yang"] = 7600,     ["second_reward_exp"] = 50,         ["second_reward_yang"] = 1010},  -- zone1_1
--     [12] = { ["zone"] = 1, ["reward_exp"] = 1075,       ["reward_yang"] = 9000,     ["second_reward_exp"] = 143,        ["second_reward_yang"] = 1197},  -- zone1_2
--     [13] = { ["zone"] = 1, ["reward_exp"] = 2750,       ["reward_yang"] = 9500,     ["second_reward_exp"] = 365,        ["second_reward_yang"] = 1263},  -- zone1_3
--     [14] = { ["zone"] = 1, ["reward_exp"] = 6000,       ["reward_yang"] = 10000,    ["second_reward_exp"] = 500,        ["second_reward_yang"] = 1330},  -- zone1_4
--     [15] = { ["zone"] = 1, ["reward_exp"] = 10750,      ["reward_yang"] = 13400,    ["second_reward_exp"] = 796,        ["second_reward_yang"] = 1782},  -- zone1_5
--     [16] = { ["zone"] = 1, ["reward_exp"] = 19000,      ["reward_yang"] = 17600,    ["second_reward_exp"] = 1406,       ["second_reward_yang"] = 2340},  -- zone1_6
--     [17] = { ["zone"] = 1, ["reward_exp"] = 42250,      ["reward_yang"] = 22800,    ["second_reward_exp"] = 3126,       ["second_reward_yang"] = 3032},  -- zone1_7
--     [18] = { ["zone"] = 1, ["reward_exp"] = 70750,      ["reward_yang"] = 33000,    ["second_reward_exp"] = 5234,       ["second_reward_yang"] = 4389},  -- zone1_8
--     [19] = { ["zone"] = 1, ["reward_exp"] = 152500,     ["reward_yang"] = 35000,    ["second_reward_exp"] = 11281,      ["second_reward_yang"] = 4655},  -- zone1_9
--     [20] = { ["zone"] = 1, ["reward_exp"] = 234250,     ["reward_yang"] = 38000,    ["second_reward_exp"] = 17328,      ["second_reward_yang"] = 5054},  -- zone1_10
--     [21] = { ["zone"] = 1, ["reward_exp"] = 309250,     ["reward_yang"] = 39000,    ["second_reward_exp"] = 22875,      ["second_reward_yang"] = 5187},  -- zone1_11
--     [22] = { ["zone"] = 1, ["reward_exp"] = 464250,     ["reward_yang"] = 42000,    ["second_reward_exp"] = 34340,      ["second_reward_yang"] = 5586},  -- zone1_12
--     [23] = { ["zone"] = 1, ["reward_exp"] = 605250,     ["reward_yang"] = 44000,    ["second_reward_exp"] = 44769,      ["second_reward_yang"] = 5852},  -- zone1_13
--     [24] = { ["zone"] = 1, ["reward_exp"] = 786250,     ["reward_yang"] = 46000,    ["second_reward_exp"] = 58157,      ["second_reward_yang"] = 6118},  -- zone1_14
--     [25] = { ["zone"] = 1, ["reward_exp"] = 1158000,    ["reward_yang"] = 48000,    ["second_reward_exp"] = 85654,      ["second_reward_yang"] = 6384},  -- zone1_15
--     [26] = { ["zone"] = 1, ["reward_exp"] = 1566000,    ["reward_yang"] = 72000,    ["second_reward_exp"] = 115832,     ["second_reward_yang"] = 9576},  -- zone1_16
--     [27] = { ["zone"] = 1, ["reward_exp"] = 1900000,    ["reward_yang"] = 76000,    ["second_reward_exp"] = 140536,     ["second_reward_yang"] = 10108},  -- zone1_17
--     [28] = { ["zone"] = 1, ["reward_exp"] = 2247500,    ["reward_yang"] = 90000,    ["second_reward_exp"] = 166239,     ["second_reward_yang"] = 11970},  -- zone1_18
--     [29] = { ["zone"] = 1, ["reward_exp"] = 2852500,    ["reward_yang"] = 100000,   ["second_reward_exp"] = 210988,     ["second_reward_yang"] = 13300},  -- zone1_19
--     [30] = { ["zone"] = 1, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,    ["second_reward_yang"] = 14523},  -- zone1_20

--     [41] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_1
--     [42] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_2
--     [43] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_3
--     [44] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_4
--     [45] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_5
--     [46] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_6
--     [47] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_7
--     [48] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_8
--     [49] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_9
--     [50] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_10
--     [51] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_11
--     [52] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_12
--     [53] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_13
--     [54] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_14
--     [55] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_15
--     [56] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_16
--     [57] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_17
--     [58] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_18
--     [59] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_19
--     [60] = { ["zone"] = 2, ["reward_exp"] = 3317500,    ["reward_yang"] = 109200,    ["second_reward_exp"] = 245382,     ["second_reward_yang"] = 14523},  -- zone2_20
-- }

dungeonZoneInfo = {
    [11] = { ["zone"] = 1, ["mob"] = 102,      ["exp_multiplier"] = 0.2,      ["gold_multiplier"] = 0.2,     },  -- zone1_1
    [12] = { ["zone"] = 1, ["mob"] = 104,      ["exp_multiplier"] = 0.3,      ["gold_multiplier"] = 0.3,     },  -- zone1_2
    [13] = { ["zone"] = 1, ["mob"] = 108,      ["exp_multiplier"] = 0.6,      ["gold_multiplier"] = 0.6,     },  -- zone1_3
    [14] = { ["zone"] = 1, ["mob"] = 109,      ["exp_multiplier"] = 0.8,      ["gold_multiplier"] = 0.8,     },  -- zone1_4
    [15] = { ["zone"] = 1, ["mob"] = 110,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_5
    [16] = { ["zone"] = 1, ["mob"] = 111,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_6
    [17] = { ["zone"] = 1, ["mob"] = 107,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_7
    [18] = { ["zone"] = 1, ["mob"] = 112,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_8
    [19] = { ["zone"] = 1, ["mob"] = 302,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_9
    [20] = { ["zone"] = 1, ["mob"] = 304,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_10
    [21] = { ["zone"] = 1, ["mob"] = 402,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_11
    [22] = { ["zone"] = 1, ["mob"] = 502,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_12
    [23] = { ["zone"] = 1, ["mob"] = 602,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_13
    [24] = { ["zone"] = 1, ["mob"] = 604,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_14
    [25] = { ["zone"] = 1, ["mob"] = 632,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_15
    [26] = { ["zone"] = 1, ["mob"] = 634,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_16
    [27] = { ["zone"] = 1, ["mob"] = 752,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_17
    [28] = { ["zone"] = 1, ["mob"] = 754,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_18
    [29] = { ["zone"] = 1, ["mob"] = 755,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_19
    [30] = { ["zone"] = 1, ["mob"] = 757,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone1_20

    [41] = { ["zone"] = 2, ["mob"] = 2107,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_1
    [42] = { ["zone"] = 2, ["mob"] = 2108,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_2
    [43] = { ["zone"] = 2, ["mob"] = 2035,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_3
    [44] = { ["zone"] = 2, ["mob"] = 2131,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_4
    [45] = { ["zone"] = 2, ["mob"] = 2072,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_5
    [46] = { ["zone"] = 2, ["mob"] = 2073,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_6
    [47] = { ["zone"] = 2, ["mob"] = 2074,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_7
    [48] = { ["zone"] = 2, ["mob"] = 2076,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_8
    [49] = { ["zone"] = 2, ["mob"] = 2202,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_9
    [50] = { ["zone"] = 2, ["mob"] = 2205,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_10
    [51] = { ["zone"] = 2, ["mob"] = 2313,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_11
    [52] = { ["zone"] = 2, ["mob"] = 2315,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_12
    [53] = { ["zone"] = 2, ["mob"] = 0000,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_13
    [54] = { ["zone"] = 2, ["mob"] = 0000,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_14
    [55] = { ["zone"] = 2, ["mob"] = 0000,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_15
    [56] = { ["zone"] = 2, ["mob"] = 0000,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_16
    [57] = { ["zone"] = 2, ["mob"] = 0000,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_17
    [58] = { ["zone"] = 2, ["mob"] = 0000,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_18
    [59] = { ["zone"] = 2, ["mob"] = 0000,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_19
    [60] = { ["zone"] = 2, ["mob"] = 0000,      ["exp_multiplier"] = 1,      ["gold_multiplier"] = 1,     },  -- zone2_20
}

function pc_isInDungeonZone(mapIndex)

    return pc.in_dungeon() and pc.get_map_index() >= mapIndex*10000 and pc.get_map_index() < (mapIndex+1)*10000
end
function pc_kickDungeonZone(mapIndex)
    if not pc.is_gm() then
        local dungeonZone = dungeonZoneInfo[mapIndex]["zone"]
        local zinfo = zoneInfo[dungeonZone]
        pc.warp_local(dungeonZone, zinfo["x"], zinfo["y"])
    end
end

function npc_makeTargetDungeonZone(npc_id, npc_name, second_npc_id, second_npc_name)
    -- if pc.getf("dungeonZone", "state") == 0 then
        local v = find_npc_by_vnum(npc_id)
        if v != 0 then
            target.vid("__TARGET_DUNG_ZONE__", v, npc_name, 1, "green")
        end
        if second_npc_id then
            -- SECOND QUEST --
            local v2 = find_npc_by_vnum(second_npc_id)
            if v2 != 0 then
                target.vid("__TARGET_SECOND_DUNG_ZONE__", v2, second_npc_name, 1, "green")
            end
            -- SECOND QUEST END --
        end
    -- end
end

function npc_beginQuestDungeonZone(npc_name)
    say_title(npc_name)
    --                                                              1
    say("Hey !")
    say("Pour sortir de cet endroit, il te faudra vaincre le boss.")
    say("Tu le trouveras au bout de ce donjon. Mais avant, il te")
    say("faudra tuer tous ses serviteurs. Bon courage !")
    target.delete("__TARGET_DUNG_ZONE__")
    pc.setf("dungeonZone", "state", 1)
end

function npc_goOutDungeonZone(map_index, npc_name)
    local dungeonInfo = dungeonZoneInfo[map_index]
    if pc.getf("dungeonZone", "state") == 2 then
        say_title(npc_name)
        say("F�licitation !")
        say("Vous avez termin� le donjon avec succ�s.")
        say("")
        say("R�compenses :")
        say("   - Points d'exp�rience")
        say("   - Yangs")

        local mob_exp = npc.npc_get_exp(dungeonInfo["mob"])
        local mob_count = d.getf("mob_count")

        pc.give_exp2(mob_exp * mob_count * dungeonInfo["exp_multiplier"])
        -- pc.give_exp2(dungeonInfo["reward_exp"])

        local mob_gold = npc.npc_get_gold(dungeonInfo["mob"])
        
        pc.changegold(mob_gold * mob_count * dungeonInfo["gold_multiplier"])
        -- pc.changegold(dungeonInfo["reward_yang"])
        target.delete("__TARGET_DUNG_ZONE__")
        wait()
    end
    local zinfo = zoneInfo[dungeonInfo["zone"]]
    pc.warp_local(dungeonInfo["zone"], zinfo["x"], zinfo["y"])
end

function d_allMobsDeadDungeonZone(nb_mob)
    local count = d.getf("mob_count") + 1
    if count ~= nb_mob then
        if count < nb_mob then
            d.setf("mob_count", count)
            d.notice("Monstres restants : "..(nb_mob - count))
            return false
        end
    end
    d.notice("Le boss est apparu, attention !")
    return true
end

function d_finishDungeonZone(npc_id, npc_name)
    if pc.getf("dungeonZone", "state") == 1 then
        pc.setf("dungeonZone", "state", 2)
    end
    local v = find_npc_by_vnum(npc_id)
    if v != 0 then
        target.vid("__TARGET_DUNG_ZONE__", v, npc_name, 1, "green")
    end
end

-- ===== SECOND QUEST ====== --

function d_secondQuestBegin(npc_name)
    say_title(npc_name)
    --                                                              1
    say("Snif..Snif...")
    say("Ma fille a disparu, je ne sais pas o� elle a pu aller..")
    say("�a fait maintenant 2 jours que je ne l'ai pas vu. Snif..")
    say("Pourrais-tu partir � sa recherche ?")
    if select("Oui", "Non") == 1 then
        say_title(npc_name)
        say("Je te remercie.")
        target.delete("__TARGET_SECOND_DUNG_ZONE__")
        d.setf("second_quest", 1)
    end
end

function d_secondQuestGirlTalk(npc_name)
    say_title(npc_name)
    --                                                              1
    say("Mamaaan !! Mamaaan ! J'ai perdu ma mamaaaan sniiiff..")
    say("Des m�chants pas beaux m'ont enlev�, je ne sais pas o� je")
    say("suiiiis sniif :'(")
    say("Oh non les voil� !! A L'AIDE !")
    wait()
    d.setf("second_quest", 2)
end

function d_secondQuestAllMobDead(nb_mob)
    local count2 = d.getf("second_mob_count") + 1;
    if count2 < nb_mob then
        d.setf("second_mob_count", count2)
        d.notice("Monstres restants : "..(nb_mob - count2))
        return false
    end
    return true
end

function d_secondQuestAfterKillMob(npc_id, npc_name)
    say("Vous avez sauv� la petite fille, retournez voir "..npc_name)
    local v = find_npc_by_vnum(npc_id)
    if v != 0 then
        target.vid("__TARGET_SECOND_DUNG_ZONE__", v, npc_name, 1, "green")
    end

    d.setf("second_quest", 3)
end

function d_secondQuestFinish(map_index, npc_name)
    say_title(npc_name)
    --                                                              1
    say("Tu as retrouv� ma fille ?! Vraiment ?! Et elle est saine et")
    say("sauve ?! Merciii �norm�ment !!")

    target.delete("__TARGET_SECOND_DUNG_ZONE__")
    d.setf("second_quest", 4)

    local dungeonInfo = dungeonZoneInfo[map_index]

    local mob_exp = npc.npc_get_exp(dungeonInfo["mob"])
    local mob_count = d.getf("mob_count")

    pc.give_exp2(mob_exp * mob_count * dungeonInfo["exp_multiplier"] / 3)

    local mob_gold = npc.npc_get_gold(dungeonInfo["mob"])
    
    pc.changegold(mob_gold * mob_count * dungeonInfo["gold_multiplier"] / 3)
end