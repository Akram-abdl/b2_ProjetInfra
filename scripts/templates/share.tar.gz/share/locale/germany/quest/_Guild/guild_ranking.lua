quest guild_ranking begin
    state start begin
		when 11000.chat."Classement des guildes" or 11002.chat."Classement des guildes" or 11004.chat."Classement des guildes" with pc.hasguild() begin
			say_title("Gardien :")
			say("")
			say("Ici vous pouvez voir le classement des guildes.")
			say("")
			say_reward(locale.guild_rank_head)
			say(guild.around_ranking_string().."[/DELAY]")
			say("")
		end

		when 11000.chat."Top 10 guildes" or 11002.chat."Top 10 guildes" or 11004.chat."Top 10 guildes" with pc.hasguild() begin
			say_title("Gardien :")
			say("")
			say("Ici vous pouvez voir le classement des 10")
			say("meilleurs guildes.")
			say("")
			say_reward (locale.guild_rank_head)
			say(guild.high_ranking_string().."[/DELAY]")
			say("")
		end
			
		when 11000.chat."Ma guilde" or 11002.chat."Ma guilde" or 11004.chat."Ma guilde" with pc.hasguild() begin
			say_title("Gardien :")
			say("")
			say("Votre guilde est class�e :")
			say_reward("Position : "..guild.get_rank().." avec "..guild.get_ladder_point().." points.")
			say("")
		end
	end
	state ___COMPLETE___ begin
	end
end

