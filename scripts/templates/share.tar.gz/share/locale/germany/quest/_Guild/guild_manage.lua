define GUILD_DUE 1000000000

quest guild_manage begin
    state start begin
		when 11002.chat."Quitter la guilde" or 11004.chat."Quitter la guilde" with pc.hasguild() and not pc.isguildmaster() and npc.get_empire() == pc.get_empire() begin
			say_title("Gardien:")
			say("")
			say("Voulez-vous vraiment quitter cette guilde ?")
			say("Je suis sur que les membres seront tr�s")
			say("d�ssus...")
			say("")
			
			local s = select("Je suis sur","je vais y r�fl�chir")

			if s==1 then
				say_title("Gardien :")
				say("")
				say("Vous avez quitt� la guilde.")
				say("")
				pc.remove_from_guild()
			end
		end

		when 11002.chat."Dissoudre la guilde" or 11004.chat."Dissoudre la guilde" with pc.hasguild() and pc.isguildmaster() and npc.get_empire() == pc.get_empire() begin
			say_title("Gardien :")
			say("")
			say("Nous avons fait beaucoup d'efforts pour cr�er cette guilde.")
			say("Et maintenant tu veux tout d�truire ? Toutes l'exp�riences")
			say("et les souvenirs seront perdus pour toujours.")
			say("")
			say("Veux-tu vraiment dissoudre cette guilde ?")
			say("")

			local s = select("Oui", "Non")

			if s==1 then
				say_title("Gardien :")
				say("")
				say("Vous avez dissous la guilde.")
				say("")
				pc.destroy_guild()
			end
		end

		when 11000.chat."Cr�er une guilde" or 11002.chat."Cr�er une guilde" or 11004.chat."Cr�er une guilde" with not pc.hasguild() and not pc.isguildmaster() and npc.get_empire() == pc.get_empire() begin
			say_title("Gardien :")
			--                                                              1
			say("Voulez-vous cr�er une guilde ? J'ai besoin de beaucoup")
			say("d'argent.")
			say_reward("Vous devrez donner : "..tostring(GUILD_DUE).." Yang.")
			if select("Oui", "Non")==2 then return end
			say("Entrez le nom de la guilde :")
			local guild_name = string.gsub(input(), "[^A-Za-z0-9]", "") -- it also clean non alphanumeric characters
			local guild_len_name = string.len(guild_name)
			if not ((2 < guild_len_name) and (guild_len_name < 12)) then
				say_reward("Le nom ne peut comporter de caract�res sp�ciaux")
				say_reward("nom doit contenir entre 3 et 11 caract�res.")
				return
			end
			say("�tes-vous s�r de vouloir cr�er la guilde ?[ENTER]"..guild_name)
			if select("Oui", "Non")==2 then return end
			-- checks begin
			if not (pc.get_gold() >= GUILD_DUE ) then
				say_reward("Pas assez de Yang.")
				return
			end
			if (pc.hasguild() or pc.isguildmaster()) then
				say_reward("Vous �tes d�j� dans une guilde.")
				return
			end
			-- checks end
			-- so many ifs, we can simplify this by using a table
			local ret = pc.make_guild0(guild_name)
			if ret==-2 then
				say_reward("[NO] guild name is invalid (strlen <2 or >11!)")
			elseif ret==-1 then
				say_reward("[NO] guild name is invalid (special chars found!)")
			elseif ret==0 then
				--                                                              1
				say_reward("La guilde n'a pas �t� cr��e. Ce nom existe d�j�.")
			elseif ret==1 then
				pc.change_gold(- GUILD_DUE )
				say_reward("Guilde cr��e avec succ�s !")
			elseif ret==2 then
				say_reward("[NO] player already part of a guild")
			elseif ret==3 then
				say_reward("[NO] player already guild master")
			end
		
			-- say_title("Gardien :")
			-- say("")
			-- say("Pour Cr�er une guilde, vous devez :")
			-- say("- �tre minimum niveau 100")
			-- say("- Poss�der 500.000.000 Yang")
			-- say("")
			-- say("Pensez-vous remplir toutes les conditions ?")
			-- say("")

			-- local s = select("Oui", "Non")

			-- if s == 2 then
			-- 	return

			-- elseif pc.get_level() < 100 then
			-- 	say_title("Gardien :")
			-- 	say("")
			-- 	say("Votre niveau est "..pc.get_level())
			-- 	say("")
			-- 	say_reward("niveau requis : 100")
			-- 	say("")
			-- 	return

			-- elseif pc.get_gold() < 500000000 then
			-- 	say_title("Gardien :")
			-- 	say("")
			-- 	say("Revenez quand vous aurez assez de yang.")
			-- 	say("")
			-- 	return
			-- end
			-- game.request_make_guild()
		end
	end
	state _COMPLETE_GUILD_MANAGE_ begin
	end
end
