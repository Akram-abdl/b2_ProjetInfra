quest gold_dungeon_zone begin
	state start begin
		when login with GoldDungeonLIB.isActive() begin
			local settings = GoldDungeonLIB.Settings();
			
			d.set_warp_location(settings["outside_index"], settings["outsidePos"][1], settings["outsidePos"][2]);
			if (party.is_party() and party.is_leader() or not party.is_party()) then
				d.regen_file("data/dungeon/gold_dungeon/regen_1a.txt");
				d.setf("GoldDugeon_level", 1);
				
				server_timer("GoldDungeon_30min_left", 15*60, d.get_map_index())
				server_loop_timer("GoldDungeon_kill_1wave", 15, d.get_map_index())
				
				d.notice("Hall of treasure: He was right, so many monsters!")
				d.notice("Hall of treasure: Kill them all!")
			end
		end
		
		when GoldDungeon_kill_1wave.server_timer begin
			if d.select(get_server_timer_arg()) then
				if (d.count_monster() == 0) then
					clear_server_timer("GoldDungeon_kill_1wave", get_server_timer_arg());
					
					d.regen_file("data/dungeon/gold_dungeon/regen_1b.txt");
					
					d.notice("Hall of treasure: You have killed all monsters!")
					d.notice("Hall of treasure: Now, destroy all stones!")
				else
					d.notice(string.format("Hall of treasure: You still have to kill %d mobs to move on.", d.count_monster()));
				end
			end
		end
			
		when 8452.kill with GoldDungeonLIB.isActive() begin
			local settings = GoldDungeonLIB.Settings();
			if d.getf("GoldDugeon_level") == 1 then
				local First_MetinCount = 5;
				d.setf("GoldDungeon_1stone", d.getf("GoldDungeon_1stone")+1);
				if (d.getf("GoldDungeon_1stone") < First_MetinCount) then
					d.notice(string.format("Hall of treasure: %d stones has left!", First_MetinCount-d.getf("GoldDungeon_1stone")))
				else
					d.notice("Hall of treasure: You've destroyed all stones!")
					d.notice(string.format("Hall of treasure: Let's talk with %s now!", mob_name(9286)))
					d.setf("GoldDugeon_level", 2)
					d.spawn_mob_dir(9286, 246, 164, 2)
				end
			end
		end
		
		when 9286.chat."What next?" with GoldDungeonLIB.isActive() and d.getf("GoldDugeon_level")== 2 begin
			addimage(25, 10, "gold_bg02.tga"); addimage(225, 150, "golden_guardian.tga") 
			say("[ENTER][ENTER]")
			say_title(mob_name(9286))			
			if party.is_party() and not party.is_leader() then
				say_reward("[ENTER]I need to talk with your leader!")
				return
			end
			say("[ENTER]It's much worse than i tought..[ENTER]They are everywhere now, disgusting.[ENTER]There is one more hall.[ENTER]I think the source of all this evil[ENTER]is hiding there. You nned to get there.[ENTER]I should be able to get you there.")
			wait()
			addimage(25, 10, "gold_bg02.tga"); addimage(225, 150, "golden_guardian.tga") 
			say("[ENTER][ENTER]")
			say_title(mob_name(9286))
			say(string.format("[ENTER]I need you to bring me a potion with[ENTER]gold liquid.[ENTER]%s has a basic potion. If you get it,[ENTER]you need to find some good liquid gold[ENTER]in one of those cans here.[ENTER]", mob_name(4069)))
			wait()
			npc.purge()
			
			d.notice("Hall of treasure: Another wave of monsters is coming!")
			
			server_timer("GoldDungeon_2wave_spawn", 5, d.get_map_index())
		end
		
		when GoldDungeon_2wave_spawn.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.regen_file("data/dungeon/gold_dungeon/regen_1c.txt");
				server_loop_timer("GoldDungeon_kill_2wave", 15, d.get_map_index())
			end
		end
		
		when GoldDungeon_kill_2wave.server_timer begin
			if d.select(get_server_timer_arg()) then
				if (d.count_monster() == 0) then
					clear_server_timer("GoldDungeon_kill_2wave", get_server_timer_arg());
					
					server_timer("GoldDungeon_1boss_spawn", 6, d.get_map_index())
					
					d.notice("Hall of treasure: Good job!")
					d.notice("Hall of treasure: Be careful, something slippery is here!")
				else
					d.notice(string.format("Hall of treasure: You still have to kill %d mobs to move on.", d.count_monster()));
				end
			end
		end
		
		when GoldDungeon_1boss_spawn.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.spawn_mob(4069, 261, 230)
			end
		end
		
		when kill with GoldDungeonLIB.isActive() and not npc.is_pc() and npc.get_race() == 4069 begin
			local settings = GoldDungeonLIB.Settings(); local medusa_2floor = 3;
			if d.getf("GoldDugeon_level") == 2 then
				GoldDungeonLIB.clearDungeon()			
				game.drop_item(settings["Items"][1], 1)
				d.setf("GoldDugeon_level", 3)	
				
				d.notice(string.format("Hall of treasure: You have killed the %s!!", mob_name(4069)))
				d.notice(string.format("Hall of treasure: Take the empty bottle and put it to the right %s", mob_name(9287)))
				
				local GoldContainerPos = settings["GoldContainerPos"]; local GoldContainerCount = table.getn(GoldContainerPos); local randomNumber = number(1, table.getn(GoldContainerPos))								
				for index = 1, GoldContainerCount, 1 do
					local TrueContainer = d.spawn_mob(9287, GoldContainerPos[index][1], GoldContainerPos[index][2])
					if index == randomNumber then
						d.set_unique("true_conatiner", TrueContainer)
					end
				end
			elseif d.getf("GoldDugeon_level") == 6 then  ---- Second floor, killing 3 Medusas
				d.setf("Medusa_2thfloor", d.getf("Medusa_2thfloor")+1);
				if (d.getf("Medusa_2thfloor") < medusa_2floor) then
					d.notice(string.format("Hall of treasure: %d %s has left!", medusa_2floor-d.getf("Medusa_2thfloor"), mob_name(4069)))
				else
					d.notice("Hall of treasure: You've got second key!")
					d.setf("GoldDugeon_level", 7)
					game.drop_item(30769, 1)
				end
			end
		end
		
		when 9287.click with GoldDungeonLIB.isActive() and d.getf("GoldDugeon_level") == 3 begin 
			local settings = GoldDungeonLIB.Settings();
			if pc.count_item(settings["Items"][1]) > 0 then
				if (npc.get_vid() == d.get_unique_vid("true_conatiner")) then
					GoldDungeonLIB.clearDungeon()
					pc.remove_item(settings["Items"][1], 1)
					pc.give_item2(settings["Items"][2], 1)
					d.setf("GoldDugeon_level", 4)
					d.spawn_mob_dir(9286, 246, 164, 2)
					
					d.notice("Hall of treasure: This was the right container")
					d.notice(string.format("Hall of treasure: Give the potion to %s", mob_name(9286)))
				else
					npc.kill()
					d.notice("Hall of treasure: This container was empty.")
				end
			else
				chat("You have no empty bottle where you can put the gold to.")
			end
		end
		
		when 9286.take with item.get_vnum() == 30768 and GoldDungeonLIB.isActive() and d.getf("GoldDugeon_level") == 4 begin
			pc.remove_item(30768, 1)
			addimage(25, 10, "gold_bg02.tga"); addimage(225, 150, "golden_guardian.tga");
			say("[ENTER][ENTER]")
			say_title(mob_name(9286))			
			say("[ENTER]Oh, this is perfect! Now I'm able to[ENTER]teleport you to the other hall.[ENTER]Just be careful. I don't know what is there.[ENTER]I can not go there. Some really strong[ENTER]power protecting the place.[ENTER][ENTER]")
			say_reward("So, good luck!")
			wait()
			setskin(NOWINDOW)
			GoldDungeonLIB.clearDungeon()			
			d.notice("Hall of treasure: You will be teleported in few seconds.")
			server_timer("GoldDungeon_2floor_jumper", 7, d.get_map_index())			
		end
		
		when GoldDungeon_2floor_jumper.server_timer begin
			if d.select(get_server_timer_arg()) then
				local settings = GoldDungeonLIB.Settings();
				d.setf("GoldDugeon_level", 5)
				d.spawn_mob_dir(9288, 521, 505, 5)
				d.regen_file("data/dungeon/gold_dungeon/regen_2a.txt");
				d.jump_all(settings["insidePos"][3], settings["insidePos"][4])
			end
		end
		
		when 9288.chat."Who are you?" with GoldDungeonLIB.isActive() and d.getf("GoldDugeon_level")== 5 begin
			addimage(25, 10, "gold_bg03.tga"); addimage(225, 150, "urashak.tga");			
			say("[ENTER][ENTER]")
			say_title(mob_name(9288))			
			if party.is_party() and not party.is_leader() then
				say_reward("[ENTER]I need to talk with your leader!")
				return
			end
			say("[ENTER]Don't ask me who I'm![ENTER]I'm whoever I want to be![ENTER]But what i really care about, what are[ENTER]you doing here? My monsters keep[ENTER]this place safe from people like you![ENTER]But we can play a game! If you can[ENTER]beat all the enemies here, i will[ENTER]give you a good reward!")
			wait()
			addimage(25, 10, "gold_bg03.tga"); addimage(225, 150, "urashak.tga");			
			say("[ENTER][ENTER]")
			say_title(mob_name(9288))
			say("[ENTER]But for now, take your weapon and[ENTER]try to stay alive.[ENTER][ENTER]Hahahaha...")
			wait()
			setskin(NOWINDOW)
			npc.purge()
			
			d.notice("Hall of treasure: Monster wave is coming! Kill them all!")			
			server_timer("GoldDungeon_3wave_spawn", 5, d.get_map_index())
		end	
		
		when GoldDungeon_3wave_spawn.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.regen_file("data/dungeon/gold_dungeon/regen_2b.txt");
				server_loop_timer("GoldDungeon_kill_3wave", 15, d.get_map_index())
			end
		end
		
		when GoldDungeon_kill_3wave.server_timer begin
			if d.select(get_server_timer_arg()) then
				if (d.count_monster() == 0) then
					clear_server_timer("GoldDungeon_kill_3wave", get_server_timer_arg());
					
					server_timer("GoldDungeon_2stone_spawn", 5, d.get_map_index())
					
					d.notice("Hall of treasure: You've killed all monsters!")
					d.notice("Hall of treasure: Destroy a stone to get a first key!")
				else
					d.notice(string.format("Hall of treasure: You still have to kill %d mobs to move on.", d.count_monster()));
				end
			end
		end
		
		when GoldDungeon_2stone_spawn.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.spawn_mob(8453, 523, 544)
			end
		end
		
		when kill with GoldDungeonLIB.isActive() and not npc.is_pc() and npc.get_race() == 8453 begin
			local settings = GoldDungeonLIB.Settings(); local Second_StoneCount = 5;
			if d.getf("GoldDugeon_level") == 5 then
				d.notice(string.format("Hall of treasure: You've got the key! Let's open first %s", mob_name(9289)))
				d.notice(string.format("Hall of treasure: Let's talk with %s now!", mob_name(9286)))
				game.drop_item(30769, 1)
			elseif d.getf("GoldDugeon_level") == 8 then
				d.setf("GoldDungeon_2stone", d.getf("GoldDungeon_2stone")+1);
				if (d.getf("GoldDungeon_2stone") < Second_StoneCount) then
					d.notice(string.format("Hall of treasure: %d stones has left!", Second_StoneCount-d.getf("GoldDungeon_2stone")))
				else
					d.notice("Hall of treasure: You've destroyed all stones!")
					d.notice(string.format("Hall of treasure: Let's open next %s!", mob_name(9289)))
					d.setf("GoldDugeon_level", 9)
					game.drop_item(30769, 1)
				end
			end
		end
				
		when 9289.take with item.get_vnum() == 30769 and GoldDungeonLIB.isActive() begin
			pc.remove_item(30769, 1)
			npc.kill()
			if d.getf("GoldDugeon_level") == 5 then
				d.setf("GoldDugeon_level", 6)
				d.notice(string.format("Hall of treasure: You've opened the first %s!", mob_name(9289)))
				d.notice(string.format("Hall of treasure: Take your weapon! %s are coming!", mob_name(4069)))
				server_timer("GoldDungeon_3boss_spawn", 5, d.get_map_index())
			elseif d.getf("GoldDugeon_level") == 7 then
				d.setf("GoldDugeon_level", 8)
				d.notice(string.format("Hall of treasure: You've opened the second %s!", mob_name(9289)))
				d.notice("Hall of treasure: Destroy all stones now!")
				d.regen_file("data/dungeon/gold_dungeon/regen_2d.txt");
			elseif d.getf("GoldDugeon_level") == 9 then
				d.setf("GoldDugeon_level", 10)
				d.notice(string.format("Hall of treasure: You've opened the third %s!", mob_name(9289)))
				d.notice("Hall of treasure: Kill all monsters now until you drop a key!")
				d.set_regen_file("data/dungeon/gold_dungeon/regen_2e.txt");
			elseif d.getf("GoldDugeon_level") == 11 then
				GoldDungeonLIB.clearDungeon()			
				d.notice(string.format("Hall of treasure: You've opened the last %s!", mob_name(9289)))
				d.spawn_mob_dir(9288, 521, 564, 5)
			end
		end
		
		when GoldDungeon_3boss_spawn.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.regen_file("data/dungeon/gold_dungeon/regen_2c.txt");
			end
		end
		
		when kill with GoldDungeonLIB.isActive() and not npc.is_pc() and d.getf("GoldDugeon_level") == 10 begin
			if number(1,150) == 1 then
				d.setf("GoldDugeon_level", 11)
				game.drop_item(30769);
				d.clear_regen();
				d.notice("Hall of treasure: You've got the key!")
				d.notice(string.format("Hall of treasure: Let's open the last %s!", mob_name(9289)))
			end
		end
		
		when 9288.chat."What do you want?" with GoldDungeonLIB.isActive() and d.getf("GoldDugeon_level")== 11 begin
			addimage(25, 10, "gold_bg01.tga"); addimage(225, 150, "urashak.tga");			
			say("[ENTER][ENTER]")
			say_title(mob_name(9288))			
			if party.is_party() and not party.is_leader() then
				say_reward("[ENTER]I need to talk with your leader!")
				return
			end
			say("[ENTER]To be honest, you surprised me![ENTER]But it's still not over![ENTER]Last two tests are still ahead[ENTER]of you![ENTER]Let's see if you survive!")
			wait()
			setskin(NOWINDOW)
			npc.purge()
			
			d.setf("GoldDugeon_level", 12)
			d.notice(string.format("Hall of treasure: Destroy all %s", mob_name(8454)))			
			server_timer("GoldDungeon_goldfrog_spawn", 3, d.get_map_index())
		end
		
		when GoldDungeon_goldfrog_spawn.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.regen_file("data/dungeon/gold_dungeon/regen_2f.txt");
			end
		end
		
		when kill with GoldDungeonLIB.isActive() and not npc.is_pc() and npc.get_race() == 8454 and d.getf("GoldDugeon_level")== 12 begin
			local settings = GoldDungeonLIB.Settings(); local GoldFrogCount = 4;
			d.setf("GoldDungeon_GoldFrog", d.getf("GoldDungeon_GoldFrog")+1);
			if (d.getf("GoldDungeon_GoldFrog") < GoldFrogCount) then
				d.notice(string.format("Hall of treasure: %d %s has left!", GoldFrogCount-d.getf("GoldDungeon_GoldFrog"), mob_name(8454)))
			else
				d.notice(string.format("Hall of treasure: You've destroyed all %s!", mob_name(8454)))
				d.notice("Hall of treasure: Real monster is coming!")
				server_timer("GoldDungeon_golddragon_spawn", 5, d.get_map_index())
			end
		end
		
		when GoldDungeon_golddragon_spawn.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.spawn_mob(4070, 522, 544)
			end
		end
		
		when kill with GoldDungeonLIB.isActive() and not npc.is_pc() and npc.get_race() == 4070 and d.getf("GoldDugeon_level")== 12 begin
			GoldDungeonLIB.clearDungeon()
			GoldDungeonLIB.clearTimers()
			d.notice("Hall of treasure: You did it!! You succesfully finished the dungeon!")
			d.notice("Hall of treasure: You will be teleported out of dungeon in 2 minutes")
			server_timer("GoldDungeon_0min_left", 120, d.get_map_index())
		end
		
		----Dungeon finish time timers
		when GoldDungeon_30min_left.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Hall of treasure: 15 minutes left!")
				server_timer("GoldDungeon_10min_left", 5*60, d.get_map_index())
			end
		end

		when GoldDungeon_10min_left.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Hall of treasure: 10 minutes left! Hurry up!")
				server_timer("GoldDungeon_5min_left", 5*60, d.get_map_index())
			end
		end

		when GoldDungeon_5min_left.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Hall of treasure: 5 minutes left! Time is running out!!!")
				server_timer("GoldDungeon_1min_left", 4*60, d.get_map_index())
			end
		end

		when GoldDungeon_1min_left.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Hall of treasure: 1 minute left! You almost failed!")
				server_timer("GoldDungeon_0min_left", 60, d.get_map_index())
			end
		end

		when GoldDungeon_0min_left.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.notice("Hall of treasure: You will be teleported out of dungeon!")
				server_timer("GoldDungeon_final_exit", 5, d.get_map_index())
			end
		end

		when GoldDungeon_final_exit.server_timer begin
			if d.select(get_server_timer_arg()) then
				d.exit_all()
			end
		end
		
		when logout with GoldDungeonLIB.isActive() begin 
			local data = GoldDungeonLIB.Settings(); local GoldItems = {30767, 30768, 30769};

			pc.setf("gold_dungeon","exit_gold_dungeon_time", get_global_time())
			pc.setqf("gold_dungeon", get_time() + 3600)
			
			for index = 1, table.getn(GoldItems) do
				pc.remove_item(GoldItems[index], pc.count_item(GoldItems[index]));
			end
		end
		
		----Dungeon enter
		when 9286.chat."Hall of treasure" with not GoldDungeonLIB.isActive() begin
			addimage(25, 10, "gold_bg01.tga"); addimage(225, 150, "golden_guardian.tga")
			say("[ENTER][ENTER]")
			say_title(string.format("%s:[ENTER]", mob_name(npc.get_race())))
			say("Hello![ENTER]I'm guardian of the place known a[ENTER]Hall of treasure.[ENTER]I was protecting this place over a decade.[ENTER]But something was awakened there.[ENTER]Really great and terrible monster.")
			wait()
			addimage(25, 10, "gold_bg01.tga"); addimage(225, 150, "golden_guardian.tga")
			say("[ENTER][ENTER]")
			say_title(string.format("%s:[ENTER]", mob_name(npc.get_race())))
			say("And now just one. I can not do this[ENTER]alone anymore. I need help![ENTER]Can you help me protect the place?[ENTER]There is a lot of treasure for everyone!")			
			if (select("Yes", "No") == 1) then
				if GoldDungeonLIB.checkEnter() then
					say_reward("[ENTER]You must finish the dungeon in 30 minutes.[ENTER]Otherwise you will be teleported out[ENTER]from the dungeon.[ENTER][ENTER]I wish you best luck!")
					wait()
					GoldDungeonLIB.CreateDungeon();
				end
			end
		end
		
		----Time reset - only for GM
		when 9286.chat."Time reset" with pc.is_gm() and not GoldDungeonLIB.isActive() begin
			addimage(25, 10, "gold_bg01.tga"); addimage(225, 150, "golden_guardian.tga")
			say("[ENTER][ENTER]")
			if select("Reset time","Close") == 2 then return end
				addimage(25, 10, "gold_bg01.tga"); addimage(225, 150, "golden_guardian.tga")
				say("[ENTER][ENTER]")
				say_title(string.format("%s:[ENTER]", mob_name(npc.get_race())))
				say("[ENTER]The time has been reseted.")
				pc.setf('gold_dungeon','exit_gold_dungeon_time', 0)
				pc.setqf("rejoin_time", get_time() - 3600)
		end	
	end
end	
		
		
