define MAIN_NPC 9020

quest cathedrale_dungeon begin
    state start begin
        --QUEST FUNCTIONS
		function settings()
			return
			{
				["cathedrale_dung_index"] = 55,
				["cathedrale_dung_warp"] = {32088, 38092},
				["level_check"] = {
					["minimum"] = 100,
					["maximum"] = 100
				},
				["keys"] = {30801, 30802},
			};
		end

		function check_range(x,y,rangeX,rangeY)
			syschat("check_range start")
			local get_x = pc.get_local_x()
			local get_y = pc.get_local_y()
			local x1 = x-rangeX --554
			local y1 = y-rangeY --542
			local x2 = x+rangeX --
			local y2 = y+rangeY --
			if(get_x > x1 and get_x < x2 and get_y > y1 and get_y < y2) then
				return true
			else
				return false
			end
		end
        
        function is_cathedraled()
			local pMapIndex = pc.get_map_index();
			local data = cathedrale_dungeon.settings();
			local map_index = data["cathedrale_dung_index"];
			return pc.in_dungeon() and pMapIndex >= map_index*10000 and pMapIndex < (map_index+1)*10000;
		end

        function check_enter()
			say_title(mob_name(MAIN_NPC))
			say("")
			local settings = cathedrale_dungeon.settings()

			if pc.get_level() < settings["level_check"]["minimum"] then
				say("Si vous voulez aller dans la cathedrale,")
				say(string.format("vous devez �tre minimum niveau %d", settings["level_check"]["minimum"]))
				say("")
				return
			end
			
			if pc.get_level() > settings["level_check"]["maximum"] then
				say("Si vous voulez aller dans la cathedrale,")
				say(string.format("vous devez �tre maximum niveau %d", settings["level_check"]["maximum"]))
				say("")
				return
			end
			
            say("Une fois le bouton appuy�, vous serez")
			say("t�l�port�s dans la cath�drale !")
			say("Faites attention � vous !")
			wait()
			cathedrale_dungeon.create_dungeon()
		end
				
		function create_dungeon()
			local settings = cathedrale_dungeon.settings()
			d.new_jump(settings["cathedrale_dung_index"], settings["cathedrale_dung_warp"][1] * 100, settings["cathedrale_dung_warp"][2] * 100)
			d.setf("cathedraledung_level", 0)
		end

		when login with cathedrale_dungeon.is_cathedraled() begin
			syschat("loop_timer start")
			loop_timer("check_coords", 3)
			syschat("loop_timer continue")
		end

		when check_coords.timer begin
			syschat("when check_coords.timer begin")
			if cathedrale_dungeon.check_range(566,570,50,30) == true then
				syschat("�a marche")
			end
		end


        when MAIN_NPC.chat."La Cath�drale" with not cathedrale_dungeon.is_cathedraled() begin
			local settings = cathedrale_dungeon.settings()
			say_title(mob_name(MAIN_NPC))
			say("")
			say("Bonjour guerrier !")
			say("Je suis Maitre Gims, le gardien de la cath�drale.")
			say("Depuis quelques temps des monstres apparaissent")
			say("des ruines de ce vieux monument, nous avons besoin")
			say("de guerriers comme vous!")
			wait()
			say_title(mob_name(MAIN_NPC))
			say("")
			say("�tes-vous assez courageux ?")
			say("Esp�rons que oui")
			say("")
			say_title("Voulez-vous entrer dans la cathedrale ?")
			if (select ("Oui", "Non") == 1) then
				cathedrale_dungeon.check_enter()
			end
		end

        when 101.kill with cathedrale_dungeon.is_cathedraled() and d.getf("cathedraledung_level") == 1 begin
			d.notice("cathedrale : GG!")
			d.notice("cathedrale: Vous serez t�l�port�s hors du donjon dans 2 minutes.")
			server_timer("cathedrale_dungeon_is_done", 115, d.get_map_index())
			d.setf("cathedraledung_level", 6)
            pc.setqf("stage", pc.getqf("stage")+1)
		end

        when cathedrale_dungeon_is_done.server_timer begin
			if d.select(get_server_timer_arg()) then
                local settings = cathedrale_dungeon.settings()
				d.notice("cathedrale: T�l�portation !!")
				d.set_warp_location(55, settings["cathedrale_dung_warp"][1], settings["cathedrale_dung_warp"][2])
			end
			
			server_timer("final_exit_cathedrale", 2, d.get_map_index())
		end
		
		when final_exit_cathedrale.server_timer begin
			if d.select(get_server_timer_arg()) then								
				d.exit_all()
			end
		end		
    end
end