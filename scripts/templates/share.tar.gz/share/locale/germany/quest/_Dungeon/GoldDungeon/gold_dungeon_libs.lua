--[[ -- Init - GoldDungeonLIB Class ]]

GoldDungeonLIB = {};

GoldDungeonLIB.Settings = function()
	if (GoldDungeonLIB.data == nil) then
		GoldDungeonLIB.data = {
			-- [[ Requirements, Items, Map info ]]
			["minimumLevel"] = 95,
			["minimumPartyMembers"] = 2,
			["golden_pass"] = 30766,
			
			["inside_index"] = 52,
			["outside_index"] = 41,
			
			["Items"] = {30767, 30768},
			
			
			["insidePos"] = {28412, 1388, 28681, 1506},
			["outsidePos"] = {9694, 2786},
			
			-- [[ Monsters, Monsters positions ]]
			
			["GoldContainerPos"] = {{249, 240}, {284, 262}, {329, 244}, {328, 198}, {286, 158}, {247, 166}, {207, 215}, {226, 281}, {279, 298}, {280, 338}, {237, 350}},
			
		};
	end
	
	return GoldDungeonLIB.data;
end


GoldDungeonLIB.clearTimers = function()
	clear_server_timer("GoldDungeon_30min_left", get_server_timer_arg())
	clear_server_timer("GoldDungeon_10min_left", get_server_timer_arg())
	clear_server_timer("GoldDungeon_5min_left", get_server_timer_arg())
	clear_server_timer("GoldDungeon_1min_left", get_server_timer_arg())
	clear_server_timer("GoldDungeon_0min_left", get_server_timer_arg())
	clear_server_timer("GoldDungeon_final_exit", get_server_timer_arg())
end

GoldDungeonLIB.isActive = function()
	local pMapIndex = pc.get_map_index(); local map_index = GoldDungeonLIB.Settings()["inside_index"];
	
	return pc.in_dungeon() and pMapIndex >= map_index*10000 and pMapIndex < (map_index+1)*10000;
end

GoldDungeonLIB.clearDungeon = function()
	if (pc.in_dungeon()) then
		d.clear_regen();
		d.kill_all();
	end return false;
end

GoldDungeonLIB.checkEnter = function()
	addimage(25, 10, "gold_bg01.tga"); addimage(225, 150, "golden_guardian.tga")
	say("[ENTER][ENTER]")
	say_title(mob_name(9286))
	local settings = GoldDungeonLIB.Settings();
	
	if party.is_party() then
		local pids = party.get_member_pids();
		local minLev, minLevCheck, itemNeed, itemNeedCheck = {}, true, {}, true;
		
		if not party.is_map_member_flag_lt("exit_gold_dungeon_time", get_global_time() - 60 * 60 ) then
			say_reward("Some members still have to wait[ENTER]until they can join the Hall of treasure[ENTER]again.")
			return false;
		end
		
		if (not party.is_leader()) then
			say("If you want to enter Hall of treasure,[ENTER]let me talk with the group leader first...")
			return false;
		end
		
		if (party.get_near_count() < settings["minimumPartyMembers"]) then
			say(string.format("If you want to enter the Hall of treasure,[ENTER]there must be atleast %d players with you...", settings["minimumPartyMembers"]))
			return false;
		end
		
		for index, pid in ipairs(pids) do
			q.begin_other_pc_block(pid);
				if (pc.get_level() < settings["minimumLevel"]) then
					table.insert(minLev, pc.get_name());
					minLevCheck = false;
				end
				
				if (pc.count_item(settings["golden_pass"]) < 1) then
					table.insert(itemNeed, string.format("%s", pc.get_name()));
					itemNeedCheck = false;
				end
			q.end_other_pc_block();
		end
		
		if (not minLevCheck) then
			say(string.format("If you want to enter the Hall of treasure,[ENTER]every each group member must be level %d.[ENTER][ENTER]The next following players don't have the necessary level:", settings["minimumLevel"]))
			for i, str in next, minLev, nil do
				say(string.format("- %s", str))
			end
			return false;
		end
		
		if (not itemNeedCheck) then
			say("If you wish to enter the Hall of treasure,[ENTER]every each group memeber must have:")
			say_item(""..item_name(30766).."", settings["golden_pass"], "")
			say("The next following players don't have the necessary objects:")
			for i, str in next, itemNeed, nil do
				say(string.format("- %s", str))
			end
			return false;
		end
		
		return true;
	else
	
		if ((get_global_time() - pc.getf("gold_dungeon","exit_gold_dungeon_time")) < 60*60) then
		
			local remaining_wait_time = (pc.getf("gold_dungeon","exit_gold_dungeon_time") - get_global_time() + 60*60)
			say("You have to wait until you can enter the dungeon again.")
			say_reward("You can go there again in: "..get_time_remaining(remaining_wait_time)..'[ENTER]')
			return
		end

		if (pc.get_level() < settings["minimumLevel"]) then
			say(string.format("The minimum level to enter the dungeon is %d.", settings["minimumLevel"]))
			return false;
		end
		
		if (pc.count_item(settings["golden_pass"]) < 1) then
			say("If you want to enter the underwater dungeon[ENTER]you must have:")
			say_item(""..item_name(30766).."", settings["golden_pass"], "")
			return false;
		end
	end
	
	return true;
end

GoldDungeonLIB.CreateDungeon = function()
	local settings = GoldDungeonLIB.Settings();
	
	if party.is_party() then
		local pids = party.get_member_pids();
		
		for i, pid in next, pids, nil do
			q.begin_other_pc_block(pid);
			pc.remove_item(settings["golden_pass"], 1);
			q.end_other_pc_block();
		end
		return d.new_jump_party(settings["inside_index"], settings["insidePos"][1], settings["insidePos"][2]);
	else
		pc.remove_item(settings["golden_pass"], 1);	
		return d.new_jump(settings["inside_index"], settings["insidePos"][1]*100, settings["insidePos"][2]*100); 
	end
end