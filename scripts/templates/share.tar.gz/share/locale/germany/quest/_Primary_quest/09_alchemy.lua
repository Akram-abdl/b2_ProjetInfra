define MAIN_TITLE "L'alchimie"

define GARDIEN_NAME "Gardien"
define GARDIEN1_VNUM 11002
define GARDIEN1_NAME "Gardien Minsoo"
define GARDIEN2_VNUM 11004
define GARDIEN2_NAME "Gardien Jinsa"
define RAVEN_VNUM 9019
define RAVEN_NAME "Raven"


quest alchemy begin
    state start begin
    end

    state part1 begin
        when enter begin
            send_letter(MAIN_TITLE)
            q.set_description("Parler au "..GARDIEN_NAME)
            local v = 0
            if pc.get_empire() == 1 then
                v = find_npc_by_vnum(GARDIEN1_VNUM) 
            else
                v = find_npc_by_vnum(GARDIEN2_VNUM) 
            end
			if v != 0 then
				target.vid("_TARGET_ALCHEMY", v, GARDIEN_NAME)
            end
        end

        when button or info begin
            say_title(MAIN_TITLE)
            --                                                              1
            if pc.getf("primary_quest", "alchemy") == 0 then
                say("Le gardien veut vous parler, retrouver le !")
                say("")
            elseif pc.getf("primary_quest", "alchemy") == 1 then
                say("Le gardien vous � recommand� d'aller voir Raven le")
                say("ma�tre de l'alchimie. Aller lui parler !")
                say("")
            else
                say("Aucune information")
            end
        end

        when login begin
            local npc_vnum = 0
            local npc_name = ""
            local desc = ""
            if pc.getf("primary_quest", "alchemy") == 0 then
                if pc.get_empire() == 1 then
                    npc_vnum = tonumber(GARDIEN1)
                else
                    npc_vnum = tonumber(GARDIEN2)
                end
                npc_name = tostring(GARDIEN_NAME)
                desc = tostring("Parler � "..GARDIEN_NAME)
            elseif pc.getf("primary_quest", "alchemy") == 1 then
                npc_vnum = tonumber(RAVEN_VNUM)
                npc_name = tostring(RAVEN_NAME)
                desc = tostring("Parler � "..RAVEN_NAME)
            else
                syschat("alchemy : "..pc.getf("primary_quest", "alchemy"))
                return
            end

            q.set_description(desc)
            send_letter(MAIN_TITLE)
            local v = find_npc_by_vnum(npc_vnum)
            if v != 0 then
                target.vid("_TARGET_ALCHEMY", v, npc_name)
            end
        end

        when GARDIEN1_VNUM.chat.MAIN_TITLE or GARDIEN2_VNUM.chat.MAIN_TITLE with pc.getf("primary_quest", "alchemy") == 0 and npc.get_empire() == pc.get_empire() begin
            say_title(GARDIEN_NAME)
            
            target.delete("_TARGET_ALCHEMY")

            --                                                              1
            say("Bonjour !")
            say("Maintenant que tu nous as rejoint, il est temps pour toi")
            say("d'apprendre le secret des pierres Nuriki. Comme tu le sais,")
            say("l'ast�roide Nuriki s'est �cras� non loin du village, ce qui")
            say("a infect� les monstres aux alentours. En r�cup�rant leur")
            say("chair, ainsi qu'une pierre magique, Raven a la possibilit� ")
            say("de les transformer en pierre Nuriki. Ce n'est pas tout, il")
            say("peut aussi en cr�er grace aux fragments de pierre Nuriki qui")
            say("se minent dans les crat�res. Ces pierres te permetteront de")
            say("cr�er des bijoux uniques, et tr�s puissants. Sans eux, tu")
            say("tu n'auras aucune chance de rester en vie.")
            say("Tu devrais aller voir Raven, il t'en dira plus � leur sujet.")
            say("")

            say_reward("Parler � Raven")

            pc.setf("primary_quest", "alchemy", 1)
            q.set_description("Parler � Raven")

            local v = find_npc_by_vnum(RAVEN_VNUM)
            if v != 0 then
                target.vid("_TARGET_ALCHEMY", v, RAVEN_NAME)
            end
        end
        when RAVEN_VNUM.chat.MAIN_TITLE or GARDIEN2_VNUM.chat.MAIN_TITLE with pc.getf("primary_quest", "alchemy") == 1 and npc.get_empire() == pc.get_empire() begin
            say_title(RAVEN_VNUM)
            target.delete("_TARGET_ALCHEMY")

            --                                                              1
            say("Tu veux en apprendre plus sur l'alchimie ? Tr�s bien je vais")
            say("t'expliquer. Pour commencer, il te faudra des pierres Nuriki.")
            say("En utilisant celles-ci, tu r�cup�reras au hasard une pierre")
            say("Nuriki brute. Tu auras la possibilit� de les am�liorer")
            say("de 3 fa�ons : Classe, puret� et Niveau.")
            say("Je pense qu'avec tout �a, tu devrais t'en sortir. Viens")
            say("Me voir en cas de probl�me.")
            say("")

            ds.give_qualification()
            
            pc.setf("primary_quest", "alchemy", 2)

            q.set_description("- Termin� -")
            set_quest_state("zone1_13_16", "part1")
            set_state("_COMPLETE_ALCHEMY_")
        end
    end
    state _COMPLETE_ALCHEMY_ begin
    end
end