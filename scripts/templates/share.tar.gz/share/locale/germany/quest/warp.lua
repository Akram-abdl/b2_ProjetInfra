quest warp begin
    state start begin
        when 9004.click or 9005.click begin
            if (not pc.can_warp()) then
                return syschat("Vous devez attendre 10 secondes avant de pouvoir vous t�l�porter.[ENTER]");
            end -- if
            local section = Warp.GetSection();
            table.insert(section, "Fermer");
            say_title("Edino :[ENTER]")
            say("O� veux-tu aller ?[ENTER]")
            local select_section = select_table(section);
            if (select_section == table.getn(section)) then
                return;
            end -- if
            local names, warp, price, min_level, max_level = Warp.GetBuildSection(select_section);
            table.insert(names, "Fermer");
            local selection = select_table(names);
            if (selection == table.getn(names)) then
                return;
            end -- if
            say_title("Edino :[ENTER]")
            say(string.format("Niveau requis : Min %d, Max: %d.", min_level[selection], max_level[selection]))
            say(string.format("Yangs requis : %d.[ENTER]", price[selection]))
            if (pc.get_level() < min_level[selection]) then
                say_reward("Votre niveau n'est pas assez �lev�, vous n'�tes donc")
                say_reward("pas autoris� � �tre t�l�port� dans cette carte.[ENTER]")
                return;
            elseif (pc.get_level() > max_level[selection]) then
                say_reward("Votre niveau est top �lev�, vous n'�tes donc pas")
                say_reward("autoris� � �tre t�l�port� dans cette carte.[ENTER]")
                return;
            elseif (pc.get_gold() < price[selection]) then
                say_reward("Vous n'avez pas assez de Yangs, vous n'�tes donc pas")
                say_reward("autoris� � �tre t�l�port� dans cette carte.[ENTER]")
                return;
            end -- if/elseif
            say("�tes-vous s�r de vouloir y aller ?[ENTER]")
            if (select("Oui, s�r !", "Non, merci..") == 1) then
                pc.change_gold(-price[selection]);
                pc.warp(warp[selection]["x"]*100, warp[selection]["y"]*100);
            end -- if
        end -- when
    end -- state
    state _COMPLETE_WARP_ begin
    end
end -- quest