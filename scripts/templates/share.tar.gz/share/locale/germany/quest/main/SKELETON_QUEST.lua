define MAIN_TITLE "__QUEST_TITLE__"

define GUTH_NPC_VNUM 9007
define GUTH_NPC_NAME "Guth"

define CRYSTAL_VNUM 29505


quest quest_name begin
    state start begin
    end

    state part1 begin
        when enter begin
            send_letter(MAIN_TITLE)
            q.set_description("Parler � "..GUTH_NPC_NAME)
            local v = find_npc_by_vnum(GUTH_NPC_VNUM)
			if v != 0 then
				target.vid("_TARGET_QUEST_NAME", v, GUTH_NPC_NAME)
            end
        end

        when button or info begin
            say_title(MAIN_TITLE)
            --                                                              1
            if pc.getf("primary_quest", "quest_name") == 0 then
                say("")
                say("")
            elseif pc.getf("primary_quest", "quest_name") == 1 then
                if pc.count_item(PAPER_VNUM) < 1 then
                    say("")
                    say("")
                    say("Vous trouverez les informations dans :")
                    say_reward("    - ")
                else
                    say("")
                    say("")
                end
            elseif pc.getf("primary_quest", "quest_name") == 2 then
                if pc.count_item(LETTER_VNUM) < 1 then
                    say("")
                    say("")
                    say("Vous trouverez les informations dans :")
                    say_reward("    - ")
                else
                    say("")
                    say("")
                end
            elseif pc.getf("primary_quest", "quest_name") == 3 then
                if pc.count_item(MASK_VNUM) < 1 then
                    say("")
                    say("")
                    say("Vous trouverez les informations dans :")
                    say_reward("    - ")
                else
                    say("")
                    say("")
                end
            elseif pc.getf("primary_quest", "quest_name") == 4 then
                if pc.getqf("has_kill_VentNoir_boss") == 0 then
                    say("")
                    say("")
                    say("Vous trouverez les informations dans :")
                    say_reward("    - ")
                else
                    say("")
                    say("")
                end
            else
                say("Aucune information")
            end
        end

        when login begin
            local npc_vnum = 0
            local npc_name = ""
            local desc = ""
            if pc.getf("primary_quest", "quest_name") == 0 then
                npc_vnum = tonumber(GUTH_NPC_VNUM)
                npc_name = tostring(GUTH_NPC_NAME)
                desc = tostring("Parler � "..GUTH_NPC_NAME)
            elseif pc.getf("primary_quest", "quest_name") == 1 then
                if pc.count_item(CRYSTAL_VNUM) < 1 then
                    desc = tostring("____DESC_IF_STATE==1____")
                else
                    npc_vnum = tonumber(GUTH_NPC_VNUM)
                    npc_name = tostring(GUTH_NPC_NAME)
                    desc = tostring("Retournez voir "..GUTH_NPC_NAME)
                end
            elseif pc.getf("primary_quest", "quest_name") == 2 then
                if pc.getqf("hasPower") ~= 1 then
                    desc = tostring("____DESC_IF_STATE==2____")
                else
                    npc_vnum = tonumber(GUTH_NPC_VNUM)
                    npc_name = tostring(GUTH_NPC_NAME)
                    desc = tostring("Retourner voir "..GUTH_NPC_NAME)
                end
            elseif pc.getf("primary_quest", "quest_name") == 3 then
                if (pc.getqf("hasPower") < 3) then
                    desc = tostring("____DESC_IF_STATE==3____")
                else
                    desc = tostring("Retourner voir "..GUTH_NPC_NAME)
                    npc_vnum = tonumber(GUTH_NPC_VNUM)
                    npc_name = tostring(GUTH_NPC_NAME)
                end
            else
                syschat("quest_name : "..pc.getf("primary_quest", "quest_name"))
                return
            end

            q.set_description(desc)
            send_letter(MAIN_TITLE)
            local v = find_npc_by_vnum(npc_vnum)
            if v != 0 then
                target.vid("_TARGET_QUEST_NAME", v, npc_name)
            end
        end

        when GUTH_NPC_VNUM.chat.MAIN_TITLE with pc.getf("primary_quest", "quest_name") == 0 begin
            say_title(GUTH_NPC_NAME)
            
            target.delete("_TARGET_QUEST_NAME")

            --                                                              1
            say("____TEXT_WHEN_TALK_NPC_WHEN_STATE==0____")
            say("____TEXT_WHEN_TALK_NPC_WHEN_STATE==0____")
            say("")

            say_reward("____TODO_WHEN_TALK_NPC_WHEN_ZONE==0____")

            pc.setf("primary_quest", "quest_name", 1)
            q.set_description("____TODO_WHEN_TALK_NPC_WHEN_ZONE==0____")
        end
        when GUTH_NPC_VNUM.chat.MAIN_TITLE with pc.getf("primary_quest", "quest_name") == 1 begin
            say_title(GUTH_NPC_NAME)
            if pc.count_item(CRYSTAL_VNUM) < 1 then
                say("____RETURN_TEXT_WHEN_TALK_NPC_WITH_ZONE==1____")
                return
            end
            target.delete("_TARGET_QUEST_NAME")

            --                                                              1
            say("____TEXT_WHEN_TALK_NPC_WHEN_STATE==1____")
            say("____TEXT_WHEN_TALK_NPC_WHEN_STATE==1____")
            say("")
            

            say_reward("____TODO_WHEN_TALK_NPC_WHEN_ZONE==1____")

            pc.setf("primary_quest", "quest_name", 2)
            q.set_description("____TODO_WHEN_TALK_NPC_WHEN_ZONE==1____")

        end
        when GUTH_NPC_VNUM.chat.MAIN_TITLE with pc.getf("primary_quest", "quest_name") == 2 begin
            say_title(GUTH_NPC_NAME)
            if pc.getqf("hasPower") ~= 1 then
                say("____RETURN_TEXT_WHEN_TALK_NPC_WITH_ZONE==2____")
                return
            end
            target.delete("_TARGET_QUEST_NAME")

            --                                                              1
            say("____TEXT_WHEN_TALK_NPC_WHEN_STATE==2____")
            say("____TEXT_WHEN_TALK_NPC_WHEN_STATE==2____")
            say("")


            say_reward("____TODO_WHEN_TALK_NPC_WHEN_ZONE==2____")

            pc.setf("primary_quest", "quest_name", 3)
            q.set_description("____TODO_WHEN_TALK_NPC_WHEN_ZONE==2____")

        end
        when GUTH_NPC_VNUM.chat.MAIN_TITLE with pc.getf("primary_quest", "quest_name") == 3 begin
            say_title(GUTH_NPC_NAME)
            if pc.count_item(MASK_VNUM) < 1 then
                say("____RETURN_TEXT_WHEN_TALK_NPC_WITH_ZONE==3____")
                return
            end
            target.delete("_TARGET_QUEST_NAME")

            --                                                              1
            say("____TEXT_WHEN_TALK_NPC_WHEN_STATE==3____")
            say("____TEXT_WHEN_TALK_NPC_WHEN_STATE==3____")
            say("")

            say_reward("Tuer le chef des Vents Noirs")

            pc.setf("primary_quest", "quest_name", 4)
            q.set_description("Tuer le chef des Vents Noir")

            pc.setqf("has_kill_VentNoir_boss", 0)

        end
        when GUTH_NPC_VNUM.chat.MAIN_TITLE with pc.getf("primary_quest", "quest_name") == 4 begin
            say_title(GUTH_NPC_NAME)
            if pc.getqf("has_kill_VentNoir_boss") == 0 then
                say("____RETURN_TEXT_WHEN_TALK_NPC_WITH_ZONE==4____")
                return
            end
            target.delete("_TARGET_QUEST_NAME")

            --                                                              1
            say("____TEXT_WHEN_TALK_NPC_WHEN_STATE==4____")
            say("____TEXT_WHEN_TALK_NPC_WHEN_STATE==4____")
            say("")

            pc.setf("primary_quest", "quest_name", 5)

            q.set_description("- Termin� -")
            set_quest_state("zone1_13_16", "part1")
            set_state("__COMPLETE_ZONE1_9_12__")
        end
        when kill with (npc.get_race() == 301 or npc.get_race() == 302) and pc.getf("primary_quest", "quest_name") == 1 and pc.get_count(PAPER_VNUM) < 1 begin
            if number(1,100) == 50 then
                game.drop_item_with_ownership(PAPER_VNUM,1)
            end
        end
        when kill with (npc.get_race() == 303 or npc.get_race() == 304) and pc.getf("primary_quest", "quest_name") == 2 and pc.get_count(LETTER_VNUM) < 1 begin
            if number(1,100) == 50 then
                game.drop_item_with_ownership(LETTER_VNUM,1)
            end
        end
        when kill with (npc.get_race() == 401 or npc.get_race() == 402) and pc.getf("primary_quest", "quest_name") == 3 and pc.get_count(MASK_VNUM) < 1 begin
            if number(1,100) == 50 then
                game.drop_item_with_ownership(MASK_VNUM,1)
            end
        end
        when VENT_NOIR_BOSS_VNUM.kill with pc.getf("primary_quest", "quest_name") == 4 begin
            pc.setqf("has_kill_VentNoir_boss", 1)
        end
    end
    state __COMPLETE_ZONE1_9_12__ begin
    end
end